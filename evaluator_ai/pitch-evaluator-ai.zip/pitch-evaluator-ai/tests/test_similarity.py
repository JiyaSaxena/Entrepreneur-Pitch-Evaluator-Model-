"""Unit tests for semantic similarity search engine."""

import pytest
import pandas as pd
import numpy as np
from src.nlp.embeddings import EmbeddingGenerator
from src.nlp.similarity import SimilarityEngine


def test_similarity_search_ranking():
    ref_data = pd.DataFrame([
        {"startup_name": "DumplingKing", "industry": "Food and Beverage", "pitch_text": "Frozen momos and dim sum snacks", "investment_decision": 1},
        {"startup_name": "CloudSecure", "industry": "Technology", "pitch_text": "Enterprise cloud cybersecurity and firewall protection", "investment_decision": 0},
        {"startup_name": "SnackBite", "industry": "Food and Beverage", "pitch_text": "Healthy organic roasted seed snacks", "investment_decision": 1}
    ])
    embedder = EmbeddingGenerator()
    ref_embs = embedder.generate_embeddings(ref_data["pitch_text"].tolist(), show_progress_bar=False)

    engine = SimilarityEngine(reference_df=ref_data, reference_embeddings=ref_embs, embedding_generator=embedder)

    query = "Artisanal steamed momos and frozen dumplings"
    results = engine.find_similar_startups(query, top_k=2)

    assert len(results) == 2
    # The most similar startup should be DumplingKing
    assert results[0]["startup_name"] == "DumplingKing"
    assert results[0]["similarity_score"] > 0.5
    assert 0.0 <= results[0]["similarity_score"] <= 1.0


def test_similarity_industry_filtering():
    ref_data = pd.DataFrame([
        {"startup_name": "FoodApp", "industry": "Food and Beverage", "pitch_text": "Restaurant menu delivery app", "investment_decision": 1},
        {"startup_name": "CodeApp", "industry": "Technology", "pitch_text": "Developer tool delivery software", "investment_decision": 0}
    ])
    embedder = EmbeddingGenerator()
    ref_embs = embedder.generate_embeddings(ref_data["pitch_text"].tolist(), show_progress_bar=False)

    engine = SimilarityEngine(reference_df=ref_data, reference_embeddings=ref_embs, embedding_generator=embedder)
    results = engine.find_similar_startups("delivery platform", top_k=1, industry_filter="Technology")

    assert len(results) == 1
    assert results[0]["startup_name"] == "CodeApp"
