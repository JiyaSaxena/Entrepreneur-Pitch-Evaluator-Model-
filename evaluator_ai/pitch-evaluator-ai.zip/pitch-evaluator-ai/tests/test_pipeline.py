"""Unit tests for the end-to-end evaluate_startup function."""

import pytest
from src.pipeline.pitch_evaluator import evaluate_startup, PitchEvaluatorPipeline


def test_evaluate_startup_output_structure():
    result = evaluate_startup(
        pitch_text="We make plant-based protein snacks using local grains and pea protein.",
        industry="Food and Beverage",
        revenue=50.0,
        monthly_sales=4.5,
        gross_margin=55.0,
        ask_amount=40.0,
        offered_equity=5.0,
        valuation_requested=800.0
    )

    expected_keys = [
        "predicted_domain",
        "domain_confidence",
        "investment_probability",
        "investment_prediction",
        "similar_startups",
        "overall_score",
        "rating_tier",
        "subscores",
        "nlp_metadata",
        "disclaimer"
    ]

    for key in expected_keys:
        assert key in result, f"Expected key '{key}' not found in pipeline output."

    assert 0.0 <= result["domain_confidence"] <= 1.0
    assert 0.0 <= result["investment_probability"] <= 1.0
    assert 0.0 <= result["overall_score"] <= 100.0
    assert isinstance(result["similar_startups"], list)
