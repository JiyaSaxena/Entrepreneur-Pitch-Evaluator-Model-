"""Unit tests for transparent AI evaluation scoring engine."""

import pytest
from src.scoring.evaluator import PitchScoreEvaluator, ScoringWeights


def test_scoring_weights_validation():
    # Valid sum
    w = ScoringWeights(
        deal_probability=0.40,
        financial_viability=0.25,
        pitch_clarity=0.15,
        valuation_reasonableness=0.10,
        domain_confidence=0.10
    )
    assert w.deal_probability == 0.40

    # Invalid sum should raise AssertionError
    with pytest.raises(AssertionError):
        ScoringWeights(deal_probability=0.50, financial_viability=0.50, pitch_clarity=0.50)


def test_pitch_score_bounds_and_components():
    evaluator = PitchScoreEvaluator()
    res = evaluator.evaluate_pitch(
        deal_probability=0.80,
        domain_confidence=0.90,
        pitch_word_count=50,
        pitch_sentence_count=3,
        revenue=150.0,
        monthly_sales=15.0,
        gross_margin=65.0,
        cash_burn=0,
        has_patents=1,
        ask_amount=50.0,
        offered_equity=5.0,
        valuation_requested=1000.0
    )

    assert "overall_ai_score" in res
    assert 0.0 <= res["overall_ai_score"] <= 100.0
    assert "subscores" in res
    assert all(0.0 <= s <= 100.0 for s in res["subscores"].values())
    assert "disclaimer" in res
    assert "rating_tier" in res
