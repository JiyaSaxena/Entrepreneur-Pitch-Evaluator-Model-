"""Unit tests for NLP feature extraction, keywords, and text statistics."""

import pytest
from src.nlp.features import NLPFeatureExtractor, extract_text_statistics, extract_entities_heuristic, extract_keywords_tfidf


def test_text_statistics():
    sample = "We make organic chips. Our revenue reached 50 lakhs!"
    stats = extract_text_statistics(sample)
    assert stats["word_count"] > 0
    assert stats["character_count"] > 0
    assert stats["sentence_count"] >= 1
    assert stats["avg_word_length"] > 0


def test_entity_extraction():
    sample = "Asking for 50 Lakhs for 5% equity at a valuation of 1000 Lakhs."
    entities = extract_entities_heuristic(sample)
    assert len(entities["percentages"]) >= 1
    assert "5%" in entities["percentages"]
    assert len(entities["money"]) >= 1


def test_tfidf_feature_extractor():
    corpus = [
        "organic fruit juice beverage brand",
        "cloud computing software saas automation",
        "frozen momos fast food dining chain",
        "ai powered medical radiology devices"
    ]
    extractor = NLPFeatureExtractor(min_df=1, max_features=50)
    extractor.fit(corpus)
    matrix = extractor.transform_tfidf(corpus)

    assert matrix.shape[0] == 4
    assert matrix.shape[1] > 0
    assert len(extractor.get_feature_names()) == matrix.shape[1]


def test_tfidf_keyword_extraction():
    corpus = [
        "organic vegan healthy nutritious almond milk beverage",
        "enterprise b2b cloud accounting platform software"
    ]
    extractor = NLPFeatureExtractor(min_df=1, max_features=50)
    extractor.fit(corpus)
    keywords = extract_keywords_tfidf(corpus[0], extractor.vectorizer, top_n=3)
    assert len(keywords) <= 3
    assert all(isinstance(k[0], str) and isinstance(k[1], float) for k in keywords)
