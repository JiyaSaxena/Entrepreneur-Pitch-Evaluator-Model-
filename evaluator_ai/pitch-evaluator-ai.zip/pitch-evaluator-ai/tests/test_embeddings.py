"""Unit tests for semantic embeddings."""

import pytest
import numpy as np
from src.nlp.embeddings import EmbeddingGenerator


def test_embedding_generation_shape():
    embedder = EmbeddingGenerator()
    text = "Smart IoT sensor device for automated indoor vertical farming."
    emb = embedder.generate_embedding(text)
    assert isinstance(emb, np.ndarray)
    assert emb.shape == (384,)
    # Normalized embeddings should have L2 norm close to 1.0
    norm = np.linalg.norm(emb)
    assert np.isclose(norm, 1.0, atol=1e-3)


def test_batch_embeddings_generation():
    embedder = EmbeddingGenerator()
    texts = [
        "AI algorithm for financial fraud detection.",
        "Eco-friendly bamboo toothbrush subscription service."
    ]
    embs = embedder.generate_embeddings(texts, batch_size=2, show_progress_bar=False)
    assert isinstance(embs, np.ndarray)
    assert embs.shape == (2, 384)
