"""Unit tests for Multimodal Text + Structured Data Fusion Classifier."""

import pytest
import pandas as pd
import numpy as np
from src.nlp.embeddings import EmbeddingGenerator
from src.models.fusion_classifier import MultimodalFusionClassifier


def test_fusion_feature_combination_and_prediction():
    texts = [
        "Artisanal healthy frozen dumplings and organic dipping sauces.",
        "Experimental biotech drug discovery requiring 10 years of clinical trials."
    ] * 6

    struct_df = pd.DataFrame({
        "yearly_revenue": [150.0, 0.0] * 6,
        "monthly_sales": [15.0, 0.0] * 6,
        "gross_margin": [65.0, 10.0] * 6,
        "net_margin": [20.0, -50.0] * 6,
        "ebitda": [15.0, -40.0] * 6,
        "cash_burn": [0, 1] * 6,
        "has_patents": [0, 1] * 6,
        "bootstrapped": [1, 0] * 6,
        "skus": [6, 1] * 6,
        "original_ask_amount": [50.0, 200.0] * 6,
        "original_offered_equity": [5.0, 2.0] * 6,
        "valuation_requested": [1000.0, 10000.0] * 6,
        "revenue_to_ask_ratio": [3.0, 0.0] * 6,
        "valuation_to_revenue_ratio": [6.6, 10000.0] * 6
    })
    labels = [1, 0] * 6

    embedder = EmbeddingGenerator()
    fusion_clf = MultimodalFusionClassifier(
        classifier_type="logistic_regression",
        embedding_generator=embedder
    )
    fusion_clf.fit(texts, struct_df, labels)

    probs = fusion_clf.predict_proba(texts[:2], struct_df.head(2))
    assert len(probs) == 2
    assert all(0.0 <= p <= 1.0 for p in probs)
    # Dumpling business with high revenue and margins should have higher deal probability than experimental drug
    assert probs[0] > probs[1]
