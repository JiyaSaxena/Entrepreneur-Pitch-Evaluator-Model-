"""Unit tests for domain and deal classification models."""

import pytest
import pandas as pd
import numpy as np
from src.models.domain_classifier import DomainClassifier
from src.models.structured_model import StructuredDealClassifier
from src.models.text_model import TextDealClassifier


def test_domain_classifier_training_and_prediction():
    texts = [
        "Organic bakery cookies and cakes for retail grocery stores.",
        "Artisanal roasted coffee beans and cafe beverages.",
        "Cloud software SaaS platform for B2B accounting automation.",
        "Enterprise CRM software for sales pipelines.",
        "Smart medical diagnostics and patient imaging equipment.",
        "Clinic management electronic health records software."
    ] * 5  # Duplicate to exceed min samples
    labels = [
        "Food and Beverage", "Food and Beverage",
        "Technology", "Technology",
        "Medical/Health", "Medical/Health"
    ] * 5

    clf = DomainClassifier(min_samples_per_class=2)
    clf.fit(texts, labels)

    pred = clf.predict_single("Delicious chocolate chip cookies and fruit juices")
    assert "predicted_domain" in pred
    assert "confidence" in pred
    assert 0.0 <= pred["confidence"] <= 1.0
    assert len(pred["top_k_predictions"]) > 0


def test_structured_deal_classifier():
    df = pd.DataFrame({
        "yearly_revenue": [100.0, 50.0, 0.0, 200.0, 10.0, 80.0] * 3,
        "monthly_sales": [10.0, 5.0, 0.0, 20.0, 1.0, 8.0] * 3,
        "gross_margin": [60.0, 50.0, 20.0, 70.0, 30.0, 55.0] * 3,
        "net_margin": [15.0, 10.0, -5.0, 25.0, 2.0, 12.0] * 3,
        "ebitda": [12.0, 8.0, -2.0, 20.0, 1.0, 10.0] * 3,
        "cash_burn": [0, 0, 1, 0, 1, 0] * 3,
        "has_patents": [1, 0, 0, 1, 0, 1] * 3,
        "bootstrapped": [1, 1, 0, 1, 0, 1] * 3,
        "skus": [5, 3, 1, 10, 2, 4] * 3,
        "original_ask_amount": [50.0, 50.0, 100.0, 75.0, 50.0, 60.0] * 3,
        "original_offered_equity": [5.0, 10.0, 5.0, 5.0, 10.0, 6.0] * 3,
        "valuation_requested": [1000.0, 500.0, 2000.0, 1500.0, 500.0, 1000.0] * 3,
        "revenue_to_ask_ratio": [2.0, 1.0, 0.0, 2.6, 0.2, 1.3] * 3,
        "valuation_to_revenue_ratio": [10.0, 10.0, 2000.0, 7.5, 50.0, 12.5] * 3,
        "investment_decision": [1, 1, 0, 1, 0, 1] * 3
    })

    clf = StructuredDealClassifier(model_type="gradient_boosting")
    clf.fit(df, target_col="investment_decision")

    probs = clf.predict_proba(df.head(2))
    assert len(probs) == 2
    assert all(0.0 <= p <= 1.0 for p in probs)


def test_text_deal_classifier():
    texts = [
        "Highly profitable organic snack business with massive retail distribution.",
        "Unproven concept with zero traction and no patent protection."
    ] * 5
    labels = [1, 0] * 5

    clf = TextDealClassifier(min_df=1, max_features=50)
    clf.fit(texts, labels)

    probs = clf.predict_proba(["Profitable snack business"])
    assert len(probs) == 1
    assert 0.0 <= probs[0] <= 1.0
