"""Unit tests for text cleaning and preprocessing."""

import pytest
import pandas as pd
import numpy as np
from src.nlp.preprocessor import clean_text_classical, clean_text_transformer, NLPPreprocessor
from src.data.cleaner import to_snake_case, clean_binary_flag


def test_snake_case_normalization():
    assert to_snake_case("Startup Name") == "startup_name"
    assert to_snake_case("Pitch Number #") == "pitch_number"
    assert to_snake_case("GrossMargin%") == "gross_margin"
    assert to_snake_case("original_ask_amount") == "original_ask_amount"


def test_clean_binary_flag():
    assert clean_binary_flag("Yes") == 1
    assert clean_binary_flag("yes") == 1
    assert clean_binary_flag(1) == 1
    assert clean_binary_flag("True") == 1
    assert clean_binary_flag("No") == 0
    assert clean_binary_flag(0) == 0
    assert clean_binary_flag(np.nan) == 0
    assert clean_binary_flag(None) == 0


def test_clean_text_classical():
    raw = "Visit https://example.com! We make 100% organic frozen Momos in Delhi."
    cleaned = clean_text_classical(raw)
    assert "https" not in cleaned
    assert "example" not in cleaned
    assert "momos" in cleaned
    assert "organic" in cleaned
    assert cleaned.islower()


def test_clean_text_transformer():
    raw = "Visit https://example.com! <b>We make organic Momos.</b>"
    cleaned = clean_text_transformer(raw)
    assert "https" not in cleaned
    assert "<b>" not in cleaned
    assert "Momos" in cleaned  # Preserves capitalization
    assert cleaned.endswith(".")


def test_nlp_preprocessor_multi_representation():
    preprocessor = NLPPreprocessor()
    res = preprocessor.transform_single("Healthy snacks for kids: http://snack.io")
    assert "raw_text" in res
    assert "clean_text" in res
    assert "transformer_text" in res
    assert "http" not in res["clean_text"]
    assert "http" not in res["transformer_text"]
