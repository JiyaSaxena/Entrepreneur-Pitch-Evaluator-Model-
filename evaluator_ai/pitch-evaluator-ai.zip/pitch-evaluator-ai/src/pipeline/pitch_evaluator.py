"""Unified end-to-end startup pitch evaluation pipeline.

Takes startup pitch text and optional business metrics, processes them through:
1. NLP Preprocessing
2. Domain / Industry Classification
3. Embedding Generation
4. Semantic Similarity Search against historical startups
5. Model-estimated Deal Prediction
6. Transparent AI Evaluation Scoring (0-100)
"""

from typing import Dict, Any, Optional, List, Union
import numpy as np
import pandas as pd
from ..nlp.preprocessor import NLPPreprocessor
from ..nlp.features import extract_text_statistics, extract_entities_heuristic
from ..nlp.embeddings import EmbeddingGenerator
from ..nlp.similarity import SimilarityEngine
from ..models.domain_classifier import DomainClassifier
from ..models.fusion_classifier import MultimodalFusionClassifier
from ..models.text_model import TextDealClassifier
from ..scoring.evaluator import PitchScoreEvaluator, ScoringWeights


class PitchEvaluatorPipeline:
    """Production-grade modular evaluation pipeline."""

    def __init__(
        self,
        domain_classifier: Optional[DomainClassifier] = None,
        fusion_classifier: Optional[MultimodalFusionClassifier] = None,
        text_classifier: Optional[TextDealClassifier] = None,
        similarity_engine: Optional[SimilarityEngine] = None,
        embedding_generator: Optional[EmbeddingGenerator] = None,
        scoring_weights: Optional[ScoringWeights] = None
    ):
        self.preprocessor = NLPPreprocessor()
        self.embedder = embedding_generator or EmbeddingGenerator()
        self.domain_classifier = domain_classifier
        self.fusion_classifier = fusion_classifier
        self.text_classifier = text_classifier
        self.similarity_engine = similarity_engine
        self.scorer = PitchScoreEvaluator(weights=scoring_weights)

    def evaluate(
        self,
        pitch_text: str,
        industry: Optional[str] = None,
        revenue: float = 0.0,
        monthly_sales: float = 0.0,
        gross_margin: float = 50.0,
        net_margin: float = 15.0,
        ebitda: float = 10.0,
        cash_burn: int = 0,
        has_patents: int = 0,
        bootstrapped: int = 1,
        skus: int = 5,
        ask_amount: float = 50.0,
        offered_equity: float = 5.0,
        valuation_requested: float = 1000.0,
        top_k_similar: int = 5
    ) -> Dict[str, Any]:
        """Execute full evaluation pipeline on a startup pitch."""
        # 1. Text Preprocessing
        text_reps = self.preprocessor.transform_single(pitch_text)
        raw_text = text_reps["raw_text"]
        clean_text = text_reps["clean_text"]
        transformer_text = text_reps["transformer_text"]

        # Text statistics
        stats = extract_text_statistics(raw_text)
        entities = extract_entities_heuristic(raw_text)

        # 2. Domain / Industry Classification
        if self.domain_classifier and self.domain_classifier.is_fitted:
            domain_result = self.domain_classifier.predict_single(raw_text)
            predicted_domain = domain_result["predicted_domain"]
            domain_confidence = domain_result["confidence"]
            top_domains = domain_result["top_k_predictions"]
        else:
            predicted_domain = industry or "General Business"
            domain_confidence = 0.75
            top_domains = [{"domain": predicted_domain, "confidence": domain_confidence}]

        # 3. Semantic Similarity Search
        if self.similarity_engine:
            similar_startups = self.similarity_engine.find_similar_startups(
                query=transformer_text,
                top_k=top_k_similar,
                industry_filter=industry if industry else None
            )
        else:
            similar_startups = []

        # 4. Investment / Deal Prediction
        # Prepare single-row structured DataFrame
        rev_to_ask = revenue / (ask_amount + 1.0)
        val_to_rev = valuation_requested / (revenue + 1.0)
        struct_df = pd.DataFrame([{
            "yearly_revenue": revenue,
            "monthly_sales": monthly_sales,
            "gross_margin": gross_margin,
            "net_margin": net_margin,
            "ebitda": ebitda,
            "cash_burn": cash_burn,
            "has_patents": has_patents,
            "bootstrapped": bootstrapped,
            "skus": skus,
            "original_ask_amount": ask_amount,
            "original_offered_equity": offered_equity,
            "valuation_requested": valuation_requested,
            "revenue_to_ask_ratio": rev_to_ask,
            "valuation_to_revenue_ratio": val_to_rev
        }])

        if self.fusion_classifier and self.fusion_classifier.is_fitted:
            prob = float(self.fusion_classifier.predict_proba([transformer_text], struct_df)[0])
        elif self.text_classifier and self.text_classifier.is_fitted:
            prob = float(self.text_classifier.predict_proba([clean_text])[0])
        else:
            # Fallback heuristic probability based on margins & traction
            prob = 0.55 if revenue > 20 else 0.45

        deal_prob = float(round(prob, 4))
        deal_pred = "Likely Investment" if deal_prob >= 0.5 else "Unlikely Investment"

        # 5. AI Evaluation Score
        score_eval = self.scorer.evaluate_pitch(
            deal_probability=deal_prob,
            domain_confidence=domain_confidence,
            pitch_word_count=int(stats["word_count"]),
            pitch_sentence_count=int(stats["sentence_count"]),
            revenue=revenue,
            monthly_sales=monthly_sales,
            gross_margin=gross_margin,
            cash_burn=cash_burn,
            has_patents=has_patents,
            ask_amount=ask_amount,
            offered_equity=offered_equity,
            valuation_requested=valuation_requested
        )

        return {
            "predicted_domain": predicted_domain,
            "domain_confidence": round(domain_confidence, 4),
            "top_domain_predictions": top_domains,
            "investment_probability": deal_prob,
            "investment_prediction": deal_pred,
            "similar_startups": similar_startups,
            "overall_score": score_eval["overall_ai_score"],
            "rating_tier": score_eval["rating_tier"],
            "subscores": score_eval["subscores"],
            "nlp_metadata": {
                "word_count": stats["word_count"],
                "sentence_count": stats["sentence_count"],
                "extracted_entities": entities
            },
            "disclaimer": score_eval["disclaimer"]
        }


# Global pipeline instance for direct imports
_GLOBAL_PIPELINE: Optional[PitchEvaluatorPipeline] = None


def get_global_pipeline() -> PitchEvaluatorPipeline:
    """Retrieve or lazily initialize default global pipeline instance."""
    global _GLOBAL_PIPELINE
    if _GLOBAL_PIPELINE is None:
        _GLOBAL_PIPELINE = PitchEvaluatorPipeline()
    return _GLOBAL_PIPELINE


def evaluate_startup(
    pitch_text: str,
    industry: Optional[str] = None,
    revenue: float = 0.0,
    monthly_sales: float = 0.0,
    gross_margin: float = 50.0,
    net_margin: float = 15.0,
    ebitda: float = 10.0,
    cash_burn: int = 0,
    has_patents: int = 0,
    bootstrapped: int = 1,
    skus: int = 5,
    ask_amount: float = 50.0,
    offered_equity: float = 5.0,
    valuation_requested: float = 1000.0,
    pipeline: Optional[PitchEvaluatorPipeline] = None
) -> Dict[str, Any]:
    """Convenience function evaluating a new startup pitch.

    Matches required signature from Section 18.
    """
    pipe = pipeline or get_global_pipeline()
    return pipe.evaluate(
        pitch_text=pitch_text,
        industry=industry,
        revenue=revenue,
        monthly_sales=monthly_sales,
        gross_margin=gross_margin,
        net_margin=net_margin,
        ebitda=ebitda,
        cash_burn=cash_burn,
        has_patents=has_patents,
        bootstrapped=bootstrapped,
        skus=skus,
        ask_amount=ask_amount,
        offered_equity=offered_equity,
        valuation_requested=valuation_requested
    )
