"""NLP feature extraction module.

Provides:
- TF-IDF extraction (unigrams, bigrams, min_df, max_features)
- Document keyword extraction based on TF-IDF importance
- Rule-based / Regex Named Entity Recognition for startups (Money, Percentages, Valuations, Locations)
- Linguistic and text statistics (word count, sentence count, char count, average word/sentence length)
"""

import re
from typing import List, Dict, Tuple, Optional, Any
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer


# Curated startup domain keyword seeds
STARTUP_KEYWORD_TAXONOMY = {
    "Technology": ["ai", "software", "platform", "cloud", "saas", "app", "iot", "algorithm", "data", "automation"],
    "Food & Beverage": ["food", "beverage", "organic", "snacks", "healthy", "beverages", "drink", "nutrition", "frozen"],
    "Healthcare & Medical": ["health", "medical", "patient", "clinical", "hospital", "doctor", "diagnosis", "therapy", "wellness"],
    "E-commerce & Retail": ["ecommerce", "marketplace", "d2c", "retail", "brand", "online", "store", "fashion", "apparel"],
    "Fintech & Web3": ["fintech", "payment", "bank", "crypto", "blockchain", "lending", "credit", "investment", "wallet"],
    "Sustainability & CleanTech": ["solar", "electric", "ev", "clean", "sustainable", "waste", "green", "renewable", "eco"]
}


def extract_text_statistics(text: str) -> Dict[str, float]:
    """Calculate linguistic and text statistics for a pitch description.

    Returns:
        Dictionary containing:
            - word_count
            - character_count
            - sentence_count
            - avg_word_length
            - avg_sentence_length
            - numeric_token_count
            - uppercase_word_ratio
    """
    if not isinstance(text, str) or not text.strip():
        return {
            "word_count": 0,
            "character_count": 0,
            "sentence_count": 0,
            "avg_word_length": 0.0,
            "avg_sentence_length": 0.0,
            "numeric_token_count": 0,
            "uppercase_word_ratio": 0.0
        }

    raw = text.strip()
    words = raw.split()
    word_count = len(words)
    char_count = len(raw)

    # Approximate sentence splitting
    sentences = [s.strip() for s in re.split(r"[.!?]+", raw) if s.strip()]
    sentence_count = max(1, len(sentences))

    # Average word length
    avg_word_len = np.mean([len(w) for w in words]) if word_count > 0 else 0.0
    avg_sent_len = word_count / sentence_count if sentence_count > 0 else 0.0

    # Numeric tokens (e.g. $50k, 10%, 2021)
    numeric_tokens = sum(bool(re.search(r"\d", w)) for w in words)

    # Uppercase tokens (excluding short acronyms)
    uppercase_words = sum(w.isupper() and len(w) > 1 for w in words)
    uppercase_ratio = uppercase_words / word_count if word_count > 0 else 0.0

    return {
        "word_count": float(word_count),
        "character_count": float(char_count),
        "sentence_count": float(sentence_count),
        "avg_word_length": float(round(avg_word_len, 2)),
        "avg_sentence_length": float(round(avg_sent_len, 2)),
        "numeric_token_count": float(numeric_tokens),
        "uppercase_word_ratio": float(round(uppercase_ratio, 4))
    }


def extract_entities_heuristic(text: str) -> Dict[str, List[str]]:
    """Extract domain-specific startup entities using robust regex heuristics.

    Extracts:
        - money_mentions: e.g. '$1M', 'Rs 50 Lakhs', '1000000 USD'
        - percentage_mentions: e.g. '5%', '10 percent equity'
        - valuation_mentions: e.g. 'valuation of 20 Cr'
        - potential_locations: capitalized geographic terms or city mentions
    """
    if not isinstance(text, str):
        return {"money": [], "percentages": [], "valuations": [], "locations": []}

    # Money regex
    money_pattern = r"(?:(?:\$|₹|Rs\.?|INR|USD)\s*\d+(?:,\d+)*(?:\.\d+)?\s*(?:k|m|b|million|billion|lakh|lakhs|crore|crores|cr)?|\b\d+(?:\.\d+)?\s*(?:lakh|lakhs|crore|crores|million|billion)\b)"
    money = re.findall(money_pattern, text, re.IGNORECASE)

    # Percentages
    pct_pattern = r"\d+(?:\.\d+)?\s*(?:%|percent\b)"
    percentages = re.findall(pct_pattern, text, re.IGNORECASE)

    # Valuation phrases
    val_pattern = r"(?:valuation\s*(?:of|at)?\s*(?:about|around)?\s*[\$₹Rs\d\w\s.,]+)"
    val_matches = re.findall(val_pattern, text, re.IGNORECASE)

    return {
        "money": [m.strip() for m in money],
        "percentages": [p.strip() for p in percentages],
        "valuations": [v.strip() for v in val_matches],
    }


def extract_keywords_tfidf(
    text: str,
    vectorizer: TfidfVectorizer,
    top_n: int = 5
) -> List[Tuple[str, float]]:
    """Extract top-N most salient keywords from a text using a fitted TfidfVectorizer."""
    if not isinstance(text, str) or not text.strip():
        return []

    feature_names = np.array(vectorizer.get_feature_names_out())
    tfidf_vector = vectorizer.transform([text]).toarray()[0]
    non_zero_indices = tfidf_vector.argsort()[::-1]

    top_keywords = []
    for idx in non_zero_indices[:top_n]:
        score = tfidf_vector[idx]
        if score > 0.0:
            top_keywords.append((feature_names[idx], float(round(score, 4))))

    return top_keywords


class NLPFeatureExtractor:
    """Manages TF-IDF vectorization and tabular feature generation for pitch text."""

    def __init__(
        self,
        min_df: int = 2,
        max_features: int = 1000,
        ngram_range: Tuple[int, int] = (1, 2)
    ):
        self.min_df = min_df
        self.max_features = max_features
        self.ngram_range = ngram_range
        self.vectorizer = TfidfVectorizer(
            min_df=self.min_df,
            max_features=self.max_features,
            ngram_range=self.ngram_range,
            sublinear_tf=True
        )
        self.is_fitted = False

    def fit(self, texts: List[str]) -> "NLPFeatureExtractor":
        """Fit TF-IDF strictly on training texts."""
        self.vectorizer.fit(texts)
        self.is_fitted = True
        return self

    def transform_tfidf(self, texts: List[str]) -> np.ndarray:
        """Transform texts into TF-IDF feature matrix."""
        if not self.is_fitted:
            raise RuntimeError("NLPFeatureExtractor must be fitted on training data before transform.")
        return self.vectorizer.transform(texts).toarray()

    def extract_stats_df(self, texts: List[str]) -> pd.DataFrame:
        """Extract linguistic statistics DataFrame for a collection of texts."""
        stats = [extract_text_statistics(t) for t in texts]
        return pd.DataFrame(stats)

    def get_feature_names(self) -> List[str]:
        """Return list of TF-IDF feature vocabulary tokens."""
        if not self.is_fitted:
            return []
        return list(self.vectorizer.get_feature_names_out())
