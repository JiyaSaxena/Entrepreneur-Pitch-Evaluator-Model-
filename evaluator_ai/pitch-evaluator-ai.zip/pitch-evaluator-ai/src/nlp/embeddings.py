"""Semantic embeddings generator module using Sentence Transformers.

Implements all-MiniLM-L6-v2 embeddings generation with automatic device detection
(GPU if available, otherwise graceful fallback to CPU).
"""

from pathlib import Path
from typing import List, Union
import numpy as np
import torch
from sentence_transformers import SentenceTransformer


DEFAULT_MODEL_NAME = "all-MiniLM-L6-v2"


class EmbeddingGenerator:
    """Reusable sentence embedding generator wrapping SentenceTransformer."""

    def __init__(
        self,
        model_name: str = DEFAULT_MODEL_NAME,
        device: Union[str, torch.device, None] = None
    ):
        self.model_name = model_name
        if device is None:
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = str(device)

        print(f"[EmbeddingGenerator] Initializing {self.model_name} on device: {self.device}")
        self.model = SentenceTransformer(self.model_name, device=self.device)
        if hasattr(self.model, "get_embedding_dimension"):
            self.embedding_dim = self.model.get_embedding_dimension()
        else:
            self.embedding_dim = self.model.get_sentence_embedding_dimension()
        print(f"[EmbeddingGenerator] Loaded successfully. Embedding dimension: {self.embedding_dim}")

    def generate_embedding(self, text: str) -> np.ndarray:
        """Generate a normalized 1D embedding vector for a single text.

        Returns:
            np.ndarray of shape (embedding_dim,)
        """
        clean = str(text).strip() if text is not None else ""
        if not clean:
            return np.zeros(self.embedding_dim, dtype=np.float32)

        emb = self.model.encode(clean, convert_to_numpy=True, normalize_embeddings=True)
        return emb.astype(np.float32)

    def generate_embeddings(
        self,
        texts: List[str],
        batch_size: int = 32,
        show_progress_bar: bool = True
    ) -> np.ndarray:
        """Generate normalized 2D embeddings matrix for a batch of texts.

        Returns:
            np.ndarray of shape (N, embedding_dim)
        """
        clean_texts = [str(t).strip() if t is not None else "" for t in texts]
        embeddings = self.model.encode(
            clean_texts,
            batch_size=batch_size,
            show_progress_bar=show_progress_bar,
            convert_to_numpy=True,
            normalize_embeddings=True
        )
        return embeddings.astype(np.float32)

    def save_embeddings(self, embeddings: np.ndarray, filepath: Union[str, Path]) -> None:
        """Save embeddings matrix to a .npy file."""
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        np.save(path, embeddings)
        print(f"[EmbeddingGenerator] Saved embeddings shape {embeddings.shape} to {path}")

    @staticmethod
    def load_embeddings(filepath: Union[str, Path]) -> np.ndarray:
        """Load embeddings matrix from a .npy file."""
        path = Path(filepath)
        if not path.exists():
            raise FileNotFoundError(f"Embeddings file not found: {path}")
        return np.load(path)
