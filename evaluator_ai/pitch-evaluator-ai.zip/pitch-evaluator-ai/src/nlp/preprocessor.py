"""NLP text preprocessing module.

Maintains distinct representations:
- raw_text: unmodified input
- clean_text: cleaned, normalized, lowercased, and optionally stopword-filtered for classical NLP/TF-IDF
- transformer_text: cleaned and unicode-normalized while preserving sentence structure and casing for transformer tokenizers
"""

import re
import unicodedata
from typing import List, Dict, Optional, Union
import pandas as pd
import nltk
from nltk.corpus import stopwords


# Ensure stopwords are available
try:
    ENGLISH_STOPWORDS = set(stopwords.words("english"))
except LookupError:
    nltk.download("stopwords", quiet=True)
    ENGLISH_STOPWORDS = set(stopwords.words("english"))

# Domain-specific terms we preserve or treat carefully
DOMAIN_TERMS = {"ai", "ml", "b2b", "b2c", "saas", "d2c", "ev", "iot", "inr", "usd"}


def normalize_unicode(text: str) -> str:
    """Normalize unicode characters (NFKD form) and remove obscure non-ASCII symbols."""
    text = unicodedata.normalize("NFKD", text)
    # Replace smart quotes and dashes
    text = text.replace("“", '"').replace("”", '"').replace("’", "'").replace("‘", "'")
    text = text.replace("—", "-").replace("–", "-")
    return text


def remove_html_and_urls(text: str) -> str:
    """Strip HTML tags and URLs."""
    # Remove HTML tags
    text = re.sub(r"<[^>]+>", " ", text)
    # Remove URLs
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)
    # Remove email addresses
    text = re.sub(r"\S+@\S+", " ", text)
    return text


def clean_text_transformer(text: str) -> str:
    """Clean text for Transformer models (DistilBERT).

    Preserves sentence capitalization, punctuation, and structure while stripping
    noise, URLs, HTML tags, and normalizing unicode/whitespace.
    """
    if not isinstance(text, str) or not text.strip():
        return ""

    text = normalize_unicode(text)
    text = remove_html_and_urls(text)
    # Normalize excessive punctuation
    text = re.sub(r"([!?.,;:])\1+", r"\1", text)
    # Normalize whitespace
    text = re.sub(r"\s+", " ", text).strip()
    return text


def clean_text_classical(
    text: str,
    remove_stopwords: bool = True,
    custom_stopwords: Optional[set] = None
) -> str:
    """Clean text for Classical NLP models (TF-IDF, Logistic Regression).

    Lowercases, removes punctuation and non-alphanumeric symbols, and removes stopwords.
    """
    if not isinstance(text, str) or not text.strip():
        return ""

    text = normalize_unicode(text)
    text = remove_html_and_urls(text)
    text = text.lower()

    # Replace special characters and non-alphanumeric with spaces, keeping alphanumeric
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    tokens = text.split()

    if remove_stopwords:
        stops = custom_stopwords if custom_stopwords is not None else ENGLISH_STOPWORDS
        # Keep tokens if not in stops or if in essential domain terms
        tokens = [t for t in tokens if t in DOMAIN_TERMS or (t not in stops and len(t) > 1)]

    return " ".join(tokens)


class NLPPreprocessor:
    """Reusable preprocessor maintaining raw, clean, and transformer text representations."""

    def __init__(self, remove_stopwords: bool = True):
        self.remove_stopwords = remove_stopwords
        self.stopwords = ENGLISH_STOPWORDS

    def transform_single(self, text: str) -> Dict[str, str]:
        """Produce dictionary with raw_text, clean_text, and transformer_text."""
        raw = str(text) if text is not None else ""
        transformer = clean_text_transformer(raw)
        clean = clean_text_classical(raw, remove_stopwords=self.remove_stopwords)

        return {
            "raw_text": raw,
            "clean_text": clean,
            "transformer_text": transformer
        }

    def transform_series(self, series: Union[List[str], pd.Series]) -> pd.DataFrame:
        """Process a series or list of pitch texts into a DataFrame with all representations."""
        records = [self.transform_single(t) for t in series]
        return pd.DataFrame(records)
