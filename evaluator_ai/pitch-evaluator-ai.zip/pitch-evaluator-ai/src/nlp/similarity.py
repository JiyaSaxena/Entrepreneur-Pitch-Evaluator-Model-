"""Semantic similarity search engine for startup pitches.

Compares query embeddings against pre-computed startup database embeddings using
exact cosine similarity, supporting optional industry filtering.
"""

from typing import List, Dict, Optional, Union
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from .embeddings import EmbeddingGenerator
from .preprocessor import clean_text_transformer


class SimilarityEngine:
    """Semantic similarity search engine across startup pitch repository."""

    def __init__(
        self,
        reference_df: pd.DataFrame,
        reference_embeddings: np.ndarray,
        embedding_generator: Optional[EmbeddingGenerator] = None
    ):
        """Initialize with startup metadata DataFrame and corresponding embedding vectors.

        Args:
            reference_df: DataFrame containing at least ['startup_name', 'pitch_text', 'industry', 'investment_decision']
            reference_embeddings: np.ndarray of shape (N, embedding_dim)
            embedding_generator: Optional pre-loaded EmbeddingGenerator
        """
        assert len(reference_df) == len(reference_embeddings), (
            f"Row count mismatch: DataFrame has {len(reference_df)} rows, "
            f"embeddings has {len(reference_embeddings)} vectors"
        )
        self.reference_df = reference_df.reset_index(drop=True).copy()
        self.reference_embeddings = reference_embeddings.astype(np.float32)
        self.embedder = embedding_generator or EmbeddingGenerator()

    def find_similar_startups(
        self,
        query: str,
        top_k: int = 5,
        industry_filter: Optional[str] = None
    ) -> List[Dict[str, Union[str, float, int]]]:
        """Search top-K most semantically similar startups for a query pitch.

        Args:
            query: Startup pitch text.
            top_k: Number of nearest neighbors to retrieve.
            industry_filter: Optional domain filter (e.g. 'Food and Beverage').

        Returns:
            List of dictionaries, each containing:
                - startup_name
                - industry
                - similarity_score (float rounded to 4 decimals)
                - pitch_description (truncated if too long)
                - investment_outcome (1/0/string)
        """
        cleaned_query = clean_text_transformer(query)
        if not cleaned_query:
            return []

        # 1. Generate query embedding (1D -> 2D)
        query_emb = self.embedder.generate_embedding(cleaned_query).reshape(1, -1)

        # 2. Filter candidate indices if industry filter is active
        if industry_filter and industry_filter.lower() != "all":
            mask = self.reference_df["industry"].astype(str).str.lower() == industry_filter.lower()
            if not mask.any():
                # Fallback to all if industry not found
                candidate_indices = np.arange(len(self.reference_df))
            else:
                candidate_indices = np.where(mask)[0]
        else:
            candidate_indices = np.arange(len(self.reference_df))

        candidate_embeddings = self.reference_embeddings[candidate_indices]

        # 3. Compute cosine similarities
        sims = cosine_similarity(query_emb, candidate_embeddings)[0]

        # 4. Rank candidates
        sorted_rel_indices = np.argsort(sims)[::-1][:top_k]
        top_indices = candidate_indices[sorted_rel_indices]

        results = []
        for idx in top_indices:
            row = self.reference_df.iloc[idx]
            sim_score = float(cosine_similarity(query_emb, self.reference_embeddings[idx:idx+1])[0][0])
            deal_val = row.get("investment_decision", 0)
            deal_str = "Received Investment / Deal" if deal_val == 1 else "No Deal"

            results.append({
                "startup_name": str(row.get("startup_name", "Unknown")),
                "industry": str(row.get("industry", "Unknown")),
                "similarity_score": round(float(sim_score), 4),
                "pitch_description": str(row.get("pitch_text", ""))[:200] + ("..." if len(str(row.get("pitch_text", ""))) > 200 else ""),
                "investment_outcome": deal_str,
                "deal_status_binary": int(deal_val)
            })

        return results
