"""NLP processing, feature extraction, embeddings, and semantic similarity."""
from .preprocessor import NLPPreprocessor, clean_text_classical, clean_text_transformer
from .features import NLPFeatureExtractor, extract_text_statistics, extract_keywords_tfidf, extract_entities_heuristic
from .embeddings import EmbeddingGenerator
from .similarity import SimilarityEngine

__all__ = [
    "NLPPreprocessor",
    "clean_text_classical",
    "clean_text_transformer",
    "NLPFeatureExtractor",
    "extract_text_statistics",
    "extract_keywords_tfidf",
    "extract_entities_heuristic",
    "EmbeddingGenerator",
    "SimilarityEngine"
]
