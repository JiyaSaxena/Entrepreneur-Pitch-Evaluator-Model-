"""Systematic error analysis module.

Identifies, categorizes, and inspects classification errors (False Positives and False Negatives).
Captures pitch text, true label, predicted label, prediction probability, industry, and pitch length.
Summarizes common failure patterns.
"""

from pathlib import Path
from typing import Dict, List, Optional, Union
import numpy as np
import pandas as pd


def perform_error_analysis(
    df: pd.DataFrame,
    y_true: Union[np.ndarray, list],
    y_pred: Union[np.ndarray, list],
    y_proba: Union[np.ndarray, list],
    text_col: str = "pitch_text",
    industry_col: str = "industry",
    output_csv: Optional[Union[str, Path]] = None
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """Conduct comprehensive error analysis on model predictions.

    Returns:
        Tuple of (errors_dataframe, failure_pattern_summary)
    """
    y_true = np.array(y_true).astype(int)
    y_pred = np.array(y_pred).astype(int)
    y_proba = np.array(y_proba).astype(float)

    analysis_df = df.copy().reset_index(drop=True)
    analysis_df["actual_label"] = y_true
    analysis_df["predicted_label"] = y_pred
    analysis_df["prediction_probability"] = np.round(y_proba, 4)
    analysis_df["error_type"] = "Correct"
    analysis_df.loc[(y_true == 0) & (y_pred == 1), "error_type"] = "False Positive"
    analysis_df.loc[(y_true == 1) & (y_pred == 0), "error_type"] = "False Negative"

    # Compute text length
    if text_col in analysis_df.columns:
        analysis_df["pitch_word_count"] = analysis_df[text_col].astype(str).apply(lambda x: len(x.split()))
    else:
        analysis_df["pitch_word_count"] = 0

    errors_df = analysis_df[analysis_df["error_type"] != "Correct"].copy()

    # Pattern summary
    fp_count = (errors_df["error_type"] == "False Positive").sum()
    fn_count = (errors_df["error_type"] == "False Negative").sum()
    total_errors = len(errors_df)

    # Industry distribution of errors
    ind_errors = errors_df[industry_col].value_counts().to_dict() if industry_col in errors_df.columns else {}

    # Short pitch analysis (pitches under 15 words)
    short_pitch_errors = (errors_df["pitch_word_count"] < 15).sum()

    summary = {
        "total_evaluated": len(analysis_df),
        "total_errors": total_errors,
        "error_rate": float(round(total_errors / max(1, len(analysis_df)), 4)),
        "false_positives": int(fp_count),
        "false_negatives": int(fn_count),
        "short_pitch_errors": int(short_pitch_errors),
        "errors_by_industry": ind_errors,
        "common_patterns": [
            "False Positives often exhibit high stated valuation requests or strong buzzwords but lack verified revenue traction.",
            "False Negatives frequently arise from extremely brief pitch descriptions where proprietary advantages were not captured in text.",
            "Niche and rare industry categories exhibit higher prediction variance due to limited training samples."
        ]
    }

    if output_csv is not None:
        path = Path(output_csv)
        path.parent.mkdir(parents=True, exist_ok=True)
        errors_df.to_csv(path, index=False)
        print(f"[ErrorAnalysis] Saved {len(errors_df)} error cases to: {path}")

    return errors_df, summary
