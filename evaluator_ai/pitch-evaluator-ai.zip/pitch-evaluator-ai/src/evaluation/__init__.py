"""Model evaluation, comparison, visualization, and error analysis modules."""
from .metrics import compute_classification_metrics, plot_confusion_matrix, plot_roc_curve, plot_precision_recall_curve
from .comparison import ModelComparator
from .error_analysis import perform_error_analysis

__all__ = [
    "compute_classification_metrics",
    "plot_confusion_matrix",
    "plot_roc_curve",
    "plot_precision_recall_curve",
    "ModelComparator",
    "perform_error_analysis"
]
