"""Metrics calculation and visualization module.

Generates:
- Accuracy, Precision, Recall, F1-score, ROC-AUC
- Confusion matrix visualization
- ROC Curves & Precision-Recall curves
"""

from pathlib import Path
from typing import Dict, Any, Optional, Union
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, roc_curve, precision_recall_curve,
    classification_report
)


def compute_classification_metrics(
    y_true: Union[np.ndarray, list],
    y_pred: Union[np.ndarray, list],
    y_proba: Optional[Union[np.ndarray, list]] = None
) -> Dict[str, float]:
    """Compute comprehensive classification metrics."""
    y_true = np.array(y_true).astype(int)
    y_pred = np.array(y_pred).astype(int)

    metrics = {
        "accuracy": float(round(accuracy_score(y_true, y_pred), 4)),
        "precision": float(round(precision_score(y_true, y_pred, zero_division=0), 4)),
        "recall": float(round(recall_score(y_true, y_pred, zero_division=0), 4)),
        "f1_score": float(round(f1_score(y_true, y_pred, zero_division=0), 4)),
    }

    if y_proba is not None:
        y_proba = np.array(y_proba).astype(float)
        try:
            metrics["roc_auc"] = float(round(roc_auc_score(y_true, y_proba), 4))
        except ValueError:
            metrics["roc_auc"] = 0.5
    else:
        metrics["roc_auc"] = float(round(roc_auc_score(y_true, y_pred), 4))

    return metrics


def plot_confusion_matrix(
    y_true: Union[np.ndarray, list],
    y_pred: Union[np.ndarray, list],
    title: str = "Confusion Matrix",
    filepath: Optional[Union[str, Path]] = None,
    class_names: Optional[list] = None
) -> None:
    """Plot and save confusion matrix."""
    y_true = np.array(y_true).astype(int)
    y_pred = np.array(y_pred).astype(int)
    cm = confusion_matrix(y_true, y_pred)
    labels = class_names or ["No Deal (0)", "Deal (1)"]

    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=labels, yticklabels=labels)
    plt.title(title, fontsize=13, fontweight="bold", pad=12)
    plt.xlabel("Predicted Label", fontsize=11)
    plt.ylabel("Actual Label", fontsize=11)
    plt.tight_layout()

    if filepath is not None:
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(path, dpi=300)
        plt.close()
    else:
        plt.show()


def plot_roc_curve(
    models_dict: Dict[str, Tuple[np.ndarray, np.ndarray]],
    title: str = "ROC Curves Comparison",
    filepath: Optional[Union[str, Path]] = None
) -> None:
    """Plot multiple ROC curves on a single figure for model comparison.

    Args:
        models_dict: Dict mapping model_name -> (y_true, y_proba)
    """
    plt.figure(figsize=(7, 6))

    for name, (y_true, y_proba) in models_dict.items():
        fpr, tpr, _ = roc_curve(y_true, y_proba)
        auc = roc_auc_score(y_true, y_proba)
        plt.plot(fpr, tpr, lw=2, label=f"{name} (AUC = {auc:.3f})")

    plt.plot([0, 1], [0, 1], color="gray", lw=1.5, linestyle="--", label="Random Chance (0.50)")
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel("False Positive Rate", fontsize=11)
    plt.ylabel("True Positive Rate (Recall)", fontsize=11)
    plt.title(title, fontsize=13, fontweight="bold", pad=12)
    plt.legend(loc="lower right", fontsize=10)
    plt.grid(alpha=0.3)
    plt.tight_layout()

    if filepath is not None:
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(path, dpi=300)
        plt.close()
    else:
        plt.show()


def plot_precision_recall_curve(
    models_dict: Dict[str, Tuple[np.ndarray, np.ndarray]],
    title: str = "Precision-Recall Curves Comparison",
    filepath: Optional[Union[str, Path]] = None
) -> None:
    """Plot multiple Precision-Recall curves on a single figure."""
    plt.figure(figsize=(7, 6))

    for name, (y_true, y_proba) in models_dict.items():
        precision, recall, _ = precision_recall_curve(y_true, y_proba)
        plt.plot(recall, precision, lw=2, label=name)

    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel("Recall", fontsize=11)
    plt.ylabel("Precision", fontsize=11)
    plt.title(title, fontsize=13, fontweight="bold", pad=12)
    plt.legend(loc="upper right", fontsize=10)
    plt.grid(alpha=0.3)
    plt.tight_layout()

    if filepath is not None:
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(path, dpi=300)
        plt.close()
    else:
        plt.show()
