"""Model comparison module.

Aggregates, tabulates, and visualizes comparative performance metrics across all
trained models (Structured Baseline, TF-IDF Text, DistilBERT, Multimodal Fusion).
"""

from pathlib import Path
from typing import List, Dict, Optional, Union
import pandas as pd


class ModelComparator:
    """Tracks and formats model comparison metrics."""

    def __init__(self):
        self.records: List[Dict] = []

    def add_model_result(
        self,
        model_name: str,
        feature_type: str,
        metrics: Dict[str, float],
        notes: str = ""
    ) -> None:
        """Register model evaluation metrics.

        Args:
            model_name: Name of model (e.g. 'Structured Baseline (GBM)')
            feature_type: Modality (e.g. 'Structured Financials', 'TF-IDF Unigram+Bigram')
            metrics: Dict containing accuracy, precision, recall, f1_score, roc_auc
            notes: Analytical comments or observations
        """
        self.records.append({
            "Model": model_name,
            "Feature Type": feature_type,
            "Accuracy": metrics.get("accuracy", 0.0),
            "Precision": metrics.get("precision", 0.0),
            "Recall": metrics.get("recall", 0.0),
            "F1-score": metrics.get("f1_score", 0.0),
            "ROC-AUC": metrics.get("roc_auc", 0.0),
            "Notes": notes
        })

    def get_table(self) -> pd.DataFrame:
        """Return comparison DataFrame."""
        return pd.DataFrame(self.records)

    def to_markdown(self) -> str:
        """Generate markdown table."""
        df = self.get_table()
        return df.to_markdown(index=False)

    def save_csv(self, filepath: Union[str, Path]) -> None:
        """Save comparison table to CSV."""
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.get_table().to_csv(path, index=False)
        print(f"[ModelComparator] Saved comparison table to: {path}")
