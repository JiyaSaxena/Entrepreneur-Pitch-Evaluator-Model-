"""Data loader module for Pitch Evaluator AI.

Safely reads raw datasets from the local data directory without modifying or overwriting them.
"""

import os
from pathlib import Path
from typing import Dict, Tuple, Optional
import pandas as pd


def load_csv_safely(filepath: str | Path, **kwargs) -> pd.DataFrame:
    """Read a CSV file with automatic fallback for encoding issues."""
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Dataset file not found at: {path}")

    encodings = ["utf-8", "latin1", "cp1252", "iso-8859-1"]
    for enc in encodings:
        try:
            return pd.read_csv(path, encoding=enc, low_memory=False, **kwargs)
        except (UnicodeDecodeError, UnicodeError):
            continue

    # Final attempt with error replacement
    return pd.read_csv(path, encoding="utf-8", errors="replace", low_memory=False, **kwargs)


def load_raw_datasets(raw_dir: str | Path) -> Dict[str, pd.DataFrame]:
    """Load all three raw startup datasets from raw_dir.

    Args:
        raw_dir: Path to directory containing original datasets.

    Returns:
        Dictionary with keys:
            - 'shark_tank_india': DataFrame
            - 'shark_tank_us': DataFrame
            - 'startup_valuation': DataFrame
    """
    raw_path = Path(raw_dir)

    sti_path = raw_path / "Shark Tank India.csv"
    stp_path = raw_path / "Sharktankpitchesdeals.csv"
    sv_path = raw_path / "startup_valuation_dataset.csv"

    print(f"[DataLoader] Loading raw datasets from: {raw_path}")

    sti_df = load_csv_safely(sti_path)
    stp_df = load_csv_safely(stp_path)
    sv_df = load_csv_safely(sv_path)

    print(f"  - Shark Tank India: {sti_df.shape[0]} rows, {sti_df.shape[1]} columns")
    print(f"  - Shark Tank US: {stp_df.shape[0]} rows, {stp_df.shape[1]} columns")
    print(f"  - Startup Valuation: {sv_df.shape[0]} rows, {sv_df.shape[1]} columns")

    return {
        "shark_tank_india": sti_df,
        "shark_tank_us": stp_df,
        "startup_valuation": sv_df
    }
