"""Data cleaning module for Pitch Evaluator AI.

Normalizes column names to snake_case, cleans data types, handles missing values,
and isolates potential data leakage columns.
"""

import re
from typing import Tuple, List, Dict, Any
import numpy as np
import pandas as pd


def to_snake_case(col_name: str) -> str:
    """Normalize string to snake_case."""
    s = re.sub(r"[^\w\s]", "", str(col_name).strip())
    s = re.sub(r"\s+", "_", s)
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s)
    return s.lower().strip("_")


def clean_binary_flag(val: Any) -> int:
    """Standardize string/bool/numeric binary values into 0 or 1."""
    if pd.isna(val):
        return 0
    s = str(val).strip().lower()
    if s in ["yes", "y", "true", "1", "1.0", "t"]:
        return 1
    return 0


def clean_shark_tank_india(df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, List[str]]]:
    """Clean and normalize the Shark Tank India dataset.

    Returns:
        Cleaned DataFrame and a dictionary categorizing columns into
        'pre_decision_features', 'target', 'leakage_excluded', and 'identifiers'.
    """
    df = df.copy()
    # Normalize column names
    df.columns = [to_snake_case(c) for c in df.columns]

    # Remove duplicates
    df = df.drop_duplicates().reset_index(drop=True)

    # 1. Target column formulation
    # 'accepted_offer' is 1.0 for 434 rows, 0.0 for 68, NaN for 287 (who received 0 offers)
    df["investment_decision"] = df["accepted_offer"].apply(lambda x: 1 if x == 1.0 or x == 1 else 0)

    # 2. Textual Pitch Formulation
    def compose_pitch_text(row):
        startup = str(row.get("startup_name", "The startup")).strip()
        industry = str(row.get("industry", "Unknown")).strip()
        desc = str(row.get("business_description", "")).strip()
        city = str(row.get("pitchers_city", "")).strip()
        state = str(row.get("pitchers_state", "")).strip()
        loc = f" from {city}, {state}" if (city and city != "nan") else ""

        parts = [f"{startup} is a business in the {industry} sector{loc}."]
        if desc and desc.lower() != "nan":
            parts.append(f"Business focus: {desc}.")
        return " ".join(parts)

    df["pitch_text"] = df.apply(compose_pitch_text, axis=1)

    # 3. Numeric Pre-Decision Financials
    numeric_cols = [
        "yearly_revenue", "monthly_sales", "gross_margin", "net_margin",
        "ebitda", "original_ask_amount", "original_offered_equity",
        "valuation_requested", "skus", "started_in"
    ]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
            # For financials, impute with 0 or median
            if col in ["yearly_revenue", "monthly_sales"]:
                df[col] = df[col].fillna(0.0)
            elif col in ["gross_margin", "net_margin", "ebitda"]:
                df[col] = df[col].fillna(df[col].median())
            elif col in ["original_ask_amount", "original_offered_equity", "valuation_requested"]:
                df[col] = df[col].fillna(df[col].median())
            else:
                df[col] = df[col].fillna(0.0)

    # 4. Binary Pre-Decision Flags
    binary_cols = ["cash_burn", "has_patents", "bootstrapped"]
    for col in binary_cols:
        if col in df.columns:
            df[col] = df[col].apply(clean_binary_flag)

    # 5. Derived Pre-Decision Features
    df["revenue_to_ask_ratio"] = df["yearly_revenue"] / (df["original_ask_amount"] + 1.0)
    df["valuation_to_revenue_ratio"] = df["valuation_requested"] / (df["yearly_revenue"] + 1.0)
    df["log_valuation_requested"] = np.log1p(df["valuation_requested"].clip(lower=0))
    df["log_yearly_revenue"] = np.log1p(df["yearly_revenue"].clip(lower=0))

    # Categorical normalization
    if "industry" in df.columns:
        df["industry"] = df["industry"].fillna("Unknown").astype(str).str.strip()

    # Column categorization for leakage isolation
    column_audit = {
        "identifiers": ["pitch_number", "startup_name", "episode_number", "season_number"],
        "target": ["investment_decision"],
        "pre_decision_features": [
            "pitch_text", "industry", "business_description", "pitchers_city",
            "pitchers_state", "pitchers_average_age", "started_in",
            "yearly_revenue", "monthly_sales", "gross_margin", "net_margin",
            "ebitda", "cash_burn", "has_patents", "bootstrapped", "skus",
            "original_ask_amount", "original_offered_equity", "valuation_requested",
            "revenue_to_ask_ratio", "valuation_to_revenue_ratio",
            "log_valuation_requested", "log_yearly_revenue"
        ],
        "leakage_excluded": [
            "received_offer", "accepted_offer", "total_deal_amount", "total_deal_equity",
            "total_deal_debt", "debt_interest", "deal_valuation", "number_of_sharks_in_deal",
            "deal_has_conditions", "royalty_percentage", "royalty_recouped_amount",
            "advisory_shares_equity", "namita_investment_amount", "vineeta_investment_amount",
            "anupam_investment_amount", "aman_investment_amount", "peyush_investment_amount",
            "ritesh_investment_amount", "amit_investment_amount", "guest_investment_amount"
        ]
    }

    return df, column_audit


def clean_shark_tank_us(df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, List[str]]]:
    """Clean and normalize the Shark Tank US dataset."""
    df = df.copy()
    df.columns = [to_snake_case(c) for c in df.columns]
    df = df.drop_duplicates().reset_index(drop=True)

    # Standardize column names
    rename_map = {
        "pitched_business_identifier": "startup_name",
        "pitched_business_desc": "pitch_text",
        "deal_status": "investment_decision"
    }
    df = df.rename(columns={k: v for k, v in rename_map.items() if k in df.columns})

    # Ensure clean text
    df["pitch_text"] = df["pitch_text"].fillna("").astype(str).str.strip()
    df["startup_name"] = df["startup_name"].fillna("Unknown Startup").astype(str).str.strip()
    df["investment_decision"] = pd.to_numeric(df["investment_decision"], errors="coerce").fillna(0).astype(int)

    column_audit = {
        "identifiers": ["season_epi_code", "startup_name"],
        "target": ["investment_decision"],
        "pre_decision_features": ["pitch_text"],
        "leakage_excluded": ["deal_shark"]
    }

    return df, column_audit


def clean_startup_valuation(df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, List[str]]]:
    """Clean and normalize the 50k Startup Valuation dataset."""
    df = df.copy()
    df.columns = [to_snake_case(c) for c in df.columns]
    df = df.drop_duplicates().reset_index(drop=True)

    # Target: exited as investment-worthy outcome proxy
    df["investment_decision"] = df["exited"].apply(lambda x: 1 if x in [True, 1, "True", "true"] else 0)

    # Pre-decision text formulation
    def create_description(row):
        name = str(row.get("startup_name", "Startup")).strip()
        ind = str(row.get("industry", "Technology")).strip()
        reg = str(row.get("region", "")).strip()
        country = str(row.get("country", "")).strip()
        tags = str(row.get("tags", "")).strip()
        stage = str(row.get("funding_round", "")).strip()
        loc = f" based in {reg}, {country}" if (country and country != "Unknown") else ""
        return f"{name} is an operating startup in the {ind} industry{loc}, specializing in {tags}. Recorded stage: {stage}."

    df["pitch_text"] = df.apply(create_description, axis=1)

    column_audit = {
        "identifiers": ["startup_id", "startup_name"],
        "target": ["investment_decision"],
        "pre_decision_features": [
            "pitch_text", "industry", "founded_year", "country", "region",
            "funding_round", "funding_amount_usd", "employee_count",
            "estimated_revenue_usd", "estimated_valuation_usd", "tags"
        ],
        "leakage_excluded": ["exited", "exit_type"]
    }

    return df, column_audit
