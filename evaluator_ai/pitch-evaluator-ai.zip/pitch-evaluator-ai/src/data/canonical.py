"""Canonical dataset creator and data dictionary generator.

Combines standardized records from historical pitch and startup datasets into
a unified canonical representation without fabricating missing information.
"""

from pathlib import Path
from typing import Dict, List, Tuple
import pandas as pd
import numpy as np


CANONICAL_COLUMNS = [
    "pitch_id",
    "startup_name",
    "pitch_text",
    "industry",
    "business_model",
    "market_information",
    "revenue",
    "monthly_sales",
    "funding",
    "ask_amount",
    "offered_equity",
    "valuation_requested",
    "traction_features",
    "investment_decision",
    "source"
]


def create_canonical_dataset(
    sti_df: pd.DataFrame,
    stp_df: pd.DataFrame,
    sv_df: pd.DataFrame
) -> pd.DataFrame:
    """Transform cleaned source datasets into the standardized canonical pitch schema.

    Preserves clear provenance in the 'source' column. Does not fabricate nonexistent data.
    """
    records: List[Dict] = []

    # 1. Shark Tank India
    for idx, row in sti_df.iterrows():
        pitch_num = row.get("pitch_number", idx + 1)
        traction_dict = {
            "gross_margin": row.get("gross_margin", np.nan),
            "net_margin": row.get("net_margin", np.nan),
            "ebitda": row.get("ebitda", np.nan),
            "cash_burn": row.get("cash_burn", 0),
            "has_patents": row.get("has_patents", 0),
            "bootstrapped": row.get("bootstrapped", 0),
            "skus": row.get("skus", 0)
        }
        rec = {
            "pitch_id": f"STI_{pitch_num}",
            "startup_name": row.get("startup_name", f"STI_Startup_{idx}"),
            "pitch_text": row.get("pitch_text", ""),
            "industry": row.get("industry", "Unknown"),
            "business_model": row.get("business_description", "Unknown"),
            "market_information": f"{row.get('pitchers_city', '')}, {row.get('pitchers_state', '')}".strip(", "),
            "revenue": row.get("yearly_revenue", np.nan),
            "monthly_sales": row.get("monthly_sales", np.nan),
            "funding": np.nan,  # Pre-decision historical funding not explicitly recorded
            "ask_amount": row.get("original_ask_amount", np.nan),
            "offered_equity": row.get("original_offered_equity", np.nan),
            "valuation_requested": row.get("valuation_requested", np.nan),
            "traction_features": str(traction_dict),
            "investment_decision": int(row.get("investment_decision", 0)),
            "source": "shark_tank_india"
        }
        records.append(rec)

    # 2. Shark Tank US
    for idx, row in stp_df.iterrows():
        rec = {
            "pitch_id": f"STUS_{row.get('season_epi_code', idx)}_{idx}",
            "startup_name": row.get("startup_name", f"STUS_Startup_{idx}"),
            "pitch_text": row.get("pitch_text", ""),
            "industry": "Unknown",  # Not explicitly tagged in STUS raw table
            "business_model": "Unknown",
            "market_information": "United States",
            "revenue": np.nan,
            "monthly_sales": np.nan,
            "funding": np.nan,
            "ask_amount": np.nan,
            "offered_equity": np.nan,
            "valuation_requested": np.nan,
            "traction_features": "{}",
            "investment_decision": int(row.get("investment_decision", 0)),
            "source": "shark_tank_us"
        }
        records.append(rec)

    # 3. Startup Valuation Dataset (Include sample or full for reference knowledge base)
    for idx, row in sv_df.iterrows():
        traction_dict = {
            "employee_count": row.get("employee_count", np.nan),
            "funding_round": row.get("funding_round", "Unknown"),
            "tags": row.get("tags", "")
        }
        rec = {
            "pitch_id": f"SV_{row.get('startup_id', idx)}",
            "startup_name": row.get("startup_name", f"SV_Startup_{idx}"),
            "pitch_text": row.get("pitch_text", ""),
            "industry": row.get("industry", "Unknown"),
            "business_model": row.get("tags", "Unknown"),
            "market_information": f"{row.get('region', '')}, {row.get('country', '')}".strip(", "),
            "revenue": row.get("estimated_revenue_usd", np.nan),
            "monthly_sales": np.nan,
            "funding": row.get("funding_amount_usd", np.nan),
            "ask_amount": np.nan,
            "offered_equity": np.nan,
            "valuation_requested": row.get("estimated_valuation_usd", np.nan),
            "traction_features": str(traction_dict),
            "investment_decision": int(row.get("investment_decision", 0)),
            "source": "startup_valuation"
        }
        records.append(rec)

    canonical_df = pd.DataFrame(records)[CANONICAL_COLUMNS]
    return canonical_df


def generate_data_dictionary() -> pd.DataFrame:
    """Generate a formal data dictionary explaining all canonical and modeling features."""
    data_dict = [
        {
            "feature_name": "pitch_id",
            "description": "Unique identifier prefixed by source origin (e.g. STI_1, STUS_826_0, SV_UUID)",
            "data_type": "string",
            "source": "all_sources",
            "used_for_modeling": False,
            "excluded_due_to_leakage": False
        },
        {
            "feature_name": "startup_name",
            "description": "Name of the startup or business entity",
            "data_type": "string",
            "source": "all_sources",
            "used_for_modeling": False,
            "excluded_due_to_leakage": False
        },
        {
            "feature_name": "pitch_text",
            "description": "Primary textual pitch narrative describing problem, solution, product, and focus",
            "data_type": "string",
            "source": "all_sources",
            "used_for_modeling": True,
            "excluded_due_to_leakage": False
        },
        {
            "feature_name": "industry",
            "description": "Target domain / sector of the startup (e.g. Food & Beverage, Tech, Healthcare)",
            "data_type": "string / categorical",
            "source": "shark_tank_india, startup_valuation",
            "used_for_modeling": True,
            "excluded_due_to_leakage": False
        },
        {
            "feature_name": "business_model",
            "description": "Short summary of business focus or operational tags",
            "data_type": "string",
            "source": "shark_tank_india, startup_valuation",
            "used_for_modeling": False,
            "excluded_due_to_leakage": False
        },
        {
            "feature_name": "market_information",
            "description": "Geographical region, city, state, or country",
            "data_type": "string",
            "source": "all_sources",
            "used_for_modeling": True,
            "excluded_due_to_leakage": False
        },
        {
            "feature_name": "revenue",
            "description": "Reported pre-decision annual revenue (in Lakhs INR for STI, USD for SV)",
            "data_type": "float",
            "source": "shark_tank_india, startup_valuation",
            "used_for_modeling": True,
            "excluded_due_to_leakage": False
        },
        {
            "feature_name": "monthly_sales",
            "description": "Reported pre-decision average monthly sales",
            "data_type": "float",
            "source": "shark_tank_india",
            "used_for_modeling": True,
            "excluded_due_to_leakage": False
        },
        {
            "feature_name": "funding",
            "description": "Total prior funding raised before the pitch",
            "data_type": "float",
            "source": "startup_valuation",
            "used_for_modeling": True,
            "excluded_due_to_leakage": False
        },
        {
            "feature_name": "ask_amount",
            "description": "Amount of investment requested by founders during pitch",
            "data_type": "float",
            "source": "shark_tank_india",
            "used_for_modeling": True,
            "excluded_due_to_leakage": False
        },
        {
            "feature_name": "offered_equity",
            "description": "Percentage of equity offered for requested ask amount",
            "data_type": "float",
            "source": "shark_tank_india",
            "used_for_modeling": True,
            "excluded_due_to_leakage": False
        },
        {
            "feature_name": "valuation_requested",
            "description": "Implied pre-decision valuation requested (ask_amount / (offered_equity / 100))",
            "data_type": "float",
            "source": "shark_tank_india, startup_valuation",
            "used_for_modeling": True,
            "excluded_due_to_leakage": False
        },
        {
            "feature_name": "traction_features",
            "description": "JSON/Dict string containing gross margin, net margin, EBITDA, cash burn, patents",
            "data_type": "string / json",
            "source": "shark_tank_india, startup_valuation",
            "used_for_modeling": True,
            "excluded_due_to_leakage": False
        },
        {
            "feature_name": "investment_decision",
            "description": "Binary ground-truth outcome: 1 = Deal / Accepted Offer / Successful Exit, 0 = No Deal",
            "data_type": "integer (0 or 1)",
            "source": "all_sources",
            "used_for_modeling": True,  # As Target
            "excluded_due_to_leakage": False
        },
        {
            "feature_name": "source",
            "description": "Dataset provenance identifier",
            "data_type": "string",
            "source": "all_sources",
            "used_for_modeling": False,
            "excluded_due_to_leakage": False
        },
        # Documented Leakage Excluded Features
        {
            "feature_name": "total_deal_amount",
            "description": "Actual investment amount agreed upon post-pitch negotiation",
            "data_type": "float",
            "source": "shark_tank_india",
            "used_for_modeling": False,
            "excluded_due_to_leakage": True
        },
        {
            "feature_name": "total_deal_equity",
            "description": "Actual equity given to sharks post-pitch",
            "data_type": "float",
            "source": "shark_tank_india",
            "used_for_modeling": False,
            "excluded_due_to_leakage": True
        },
        {
            "feature_name": "deal_valuation",
            "description": "Final post-decision negotiated valuation",
            "data_type": "float",
            "source": "shark_tank_india",
            "used_for_modeling": False,
            "excluded_due_to_leakage": True
        },
        {
            "feature_name": "deal_shark",
            "description": "Identities of investing sharks",
            "data_type": "string",
            "source": "shark_tank_india, shark_tank_us",
            "used_for_modeling": False,
            "excluded_due_to_leakage": True
        }
    ]

    return pd.DataFrame(data_dict)
