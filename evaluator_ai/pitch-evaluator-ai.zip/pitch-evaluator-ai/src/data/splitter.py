"""Data splitting module with strict stratification and leakage prevention.

Splits datasets into 70% Training, 15% Validation, and 15% Testing partitions
using random_state=42 and stratified sampling on target outcome.
"""

from typing import Tuple, Optional
import pandas as pd
from sklearn.model_selection import train_test_split


def create_train_val_test_splits(
    df: pd.DataFrame,
    target_col: str = "investment_decision",
    train_size: float = 0.70,
    val_size: float = 0.15,
    test_size: float = 0.15,
    random_state: int = 42
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Create reproducible stratified train, validation, and test splits.

    Args:
        df: Input DataFrame.
        target_col: Target column for stratified sampling.
        train_size: Proportion for training (default 0.70).
        val_size: Proportion for validation (default 0.15).
        test_size: Proportion for test (default 0.15).
        random_state: Seed for reproducibility (default 42).

    Returns:
        Tuple of (train_df, val_df, test_df)
    """
    total = train_size + val_size + test_size
    assert abs(total - 1.0) < 1e-5, f"Split proportions must sum to 1.0, got {total}"

    stratify_target = df[target_col] if target_col in df.columns else None

    # First split: train vs temp (val + test)
    temp_size = val_size + test_size
    train_df, temp_df = train_test_split(
        df,
        test_size=temp_size,
        random_state=random_state,
        stratify=stratify_target
    )

    # Second split: val vs test (proportion relative to temp_df)
    stratify_temp = temp_df[target_col] if target_col in temp_df.columns else None
    relative_test_size = test_size / temp_size

    val_df, test_df = train_test_split(
        temp_df,
        test_size=relative_test_size,
        random_state=random_state,
        stratify=stratify_temp
    )

    train_df = train_df.reset_index(drop=True)
    val_df = val_df.reset_index(drop=True)
    test_df = test_df.reset_index(drop=True)

    print(f"[DataSplitter] Created splits (random_state={random_state}):")
    print(f"  - Train: {len(train_df)} rows ({len(train_df)/len(df):.1%})")
    print(f"  - Validation: {len(val_df)} rows ({len(val_df)/len(df):.1%})")
    print(f"  - Test: {len(test_df)} rows ({len(test_df)/len(df):.1%})")

    return train_df, val_df, test_df
