"""Transparent AI startup evaluation scoring engine.

Generates an explainable overall AI evaluation score from 0 to 100
based on multi-criteria analysis:
1. Model-Estimated Investment Likelihood (40%)
2. Financial Viability & Margins (25%)
3. Pitch Clarity & Traction Indicators (15%)
4. Valuation Reasonableness (10%)
5. Domain / Industry Confidence (10%)

All weights are fully configurable.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional
import numpy as np


@dataclass
class ScoringWeights:
    """Configurable weights for AI startup evaluation score (must sum to 1.0)."""
    deal_probability: float = 0.40
    financial_viability: float = 0.25
    pitch_clarity: float = 0.15
    valuation_reasonableness: float = 0.10
    domain_confidence: float = 0.10

    def __post_init__(self):
        total = (
            self.deal_probability
            + self.financial_viability
            + self.pitch_clarity
            + self.valuation_reasonableness
            + self.domain_confidence
        )
        assert abs(total - 1.0) < 1e-4, f"Scoring weights must sum to 1.0, got {total}"


class PitchScoreEvaluator:
    """Transparent, explainable multi-factor startup pitch scoring system."""

    DISCLAIMER = (
        "Notice: This score is an academic, AI-generated evaluation based on historical "
        "startup pitch patterns. It is an analytical indicator and does not represent "
        "or guarantee financial return or real-world investment success."
    )

    def __init__(self, weights: Optional[ScoringWeights] = None):
        self.weights = weights or ScoringWeights()

    def compute_financial_subscore(
        self,
        revenue: float,
        monthly_sales: float,
        gross_margin: float,
        cash_burn: int,
        has_patents: int
    ) -> float:
        """Compute financial viability subscore on a 0-100 scale."""
        score = 50.0  # neutral starting point

        # Revenue traction bonus
        if revenue > 100:  # > 100 Lakhs (~1 Cr) or healthy revenue
            score += 20.0
        elif revenue > 20:
            score += 10.0
        elif revenue == 0:
            score -= 10.0

        # Monthly sales check
        if monthly_sales > 10:
            score += 10.0

        # Gross margin evaluation
        if gross_margin >= 60.0:
            score += 15.0
        elif gross_margin >= 40.0:
            score += 10.0
        elif gross_margin < 20.0 and gross_margin > 0:
            score -= 15.0

        # Patents and defensibility
        if has_patents == 1:
            score += 10.0

        # High cash burn penalty
        if cash_burn == 1:
            score -= 5.0

        return float(np.clip(score, 0.0, 100.0))

    def compute_clarity_subscore(self, word_count: int, sentence_count: int) -> float:
        """Compute pitch clarity subscore (0-100) based on length and structure."""
        if word_count < 10:
            return 25.0
        elif word_count < 25:
            return 55.0
        elif 25 <= word_count <= 120:
            return 90.0  # Optimal pitch length
        elif 120 < word_count <= 250:
            return 80.0
        else:
            return 70.0  # Too verbose

    def compute_valuation_subscore(
        self,
        ask_amount: float,
        offered_equity: float,
        valuation_requested: float,
        revenue: float
    ) -> float:
        """Compute valuation reasonableness subscore (0-100)."""
        score = 65.0

        # Check offered equity reasonableness (equity between 2% and 25% is typical on Shark Tank)
        if 2.0 <= offered_equity <= 20.0:
            score += 15.0
        elif offered_equity > 35.0:
            score -= 15.0  # Founder giving away too much early equity
        elif offered_equity < 1.0:
            score -= 20.0  # Asking too much for minuscule equity

        # Valuation multiple on revenue
        if revenue > 0 and valuation_requested > 0:
            multiple = valuation_requested / revenue
            if multiple <= 10.0:
                score += 20.0
            elif multiple <= 25.0:
                score += 10.0
            elif multiple > 80.0:
                score -= 25.0  # Exorbitant valuation multiple

        return float(np.clip(score, 0.0, 100.0))

    def evaluate_pitch(
        self,
        deal_probability: float,
        domain_confidence: float,
        pitch_word_count: int,
        pitch_sentence_count: int = 2,
        revenue: float = 0.0,
        monthly_sales: float = 0.0,
        gross_margin: float = 50.0,
        cash_burn: int = 0,
        has_patents: int = 0,
        ask_amount: float = 50.0,
        offered_equity: float = 5.0,
        valuation_requested: float = 1000.0
    ) -> Dict[str, Any]:
        """Compute transparent overall score and subscore breakdown.

        Returns:
            Dictionary with overall_score, breakdown, and academic disclaimer.
        """
        # Sub-dimension scores (0 to 100)
        deal_subscore = float(np.clip(deal_probability * 100.0, 0.0, 100.0))
        financial_subscore = self.compute_financial_subscore(
            revenue, monthly_sales, gross_margin, cash_burn, has_patents
        )
        clarity_subscore = self.compute_clarity_subscore(pitch_word_count, pitch_sentence_count)
        valuation_subscore = self.compute_valuation_subscore(
            ask_amount, offered_equity, valuation_requested, revenue
        )
        domain_subscore = float(np.clip(domain_confidence * 100.0, 0.0, 100.0))

        # Weighted composite score
        overall = (
            self.weights.deal_probability * deal_subscore
            + self.weights.financial_viability * financial_subscore
            + self.weights.pitch_clarity * clarity_subscore
            + self.weights.valuation_reasonableness * valuation_subscore
            + self.weights.domain_confidence * domain_subscore
        )

        overall_clamped = round(float(np.clip(overall, 0.0, 100.0)), 1)

        # Categorical rating tier
        if overall_clamped >= 80.0:
            rating_tier = "Exceptional Pitch Potential"
        elif overall_clamped >= 65.0:
            rating_tier = "Promising Pitch"
        elif overall_clamped >= 50.0:
            rating_tier = "Moderate Viability / Refinement Needed"
        else:
            rating_tier = "High Risk / Significant Structuring Needed"

        return {
            "overall_ai_score": overall_clamped,
            "rating_tier": rating_tier,
            "subscores": {
                "deal_likelihood_score": round(deal_subscore, 1),
                "financial_viability_score": round(financial_subscore, 1),
                "pitch_clarity_score": round(clarity_subscore, 1),
                "valuation_reasonableness_score": round(valuation_subscore, 1),
                "domain_alignment_score": round(domain_subscore, 1)
            },
            "weights_used": {
                "deal_probability": self.weights.deal_probability,
                "financial_viability": self.weights.financial_viability,
                "pitch_clarity": self.weights.pitch_clarity,
                "valuation_reasonableness": self.weights.valuation_reasonableness,
                "domain_confidence": self.weights.domain_confidence
            },
            "disclaimer": self.DISCLAIMER
        }
