"""Multimodal Text + Structured Data Fusion deal classification module.

Combines dense semantic text embeddings (384-d from all-MiniLM-L6-v2)
with preprocessed, scaled pre-decision business features (14-d).
Prevents preprocessing leakage by fitting all scalers strictly on training data.
"""

from pathlib import Path
from typing import List, Dict, Optional, Any, Union
import numpy as np
import pandas as pd
import joblib
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from ..nlp.embeddings import EmbeddingGenerator
from .structured_model import STRUCTURED_FEATURE_COLS


class MultimodalFusionClassifier:
    """Multimodal feature fusion model combining text embeddings and structured metrics."""

    def __init__(
        self,
        classifier_type: str = "gradient_boosting",
        feature_cols: Optional[List[str]] = None,
        embedding_generator: Optional[EmbeddingGenerator] = None,
        random_state: int = 42
    ):
        self.classifier_type = classifier_type
        self.feature_cols = feature_cols or STRUCTURED_FEATURE_COLS
        self.random_state = random_state

        self.embedder = embedding_generator or EmbeddingGenerator()
        self.imputer = SimpleImputer(strategy="median")
        self.scaler = StandardScaler()

        if classifier_type == "random_forest":
            self.classifier = RandomForestClassifier(
                n_estimators=150,
                max_depth=6,
                class_weight="balanced",
                random_state=self.random_state
            )
        elif classifier_type == "logistic_regression":
            self.classifier = LogisticRegression(
                C=1.0,
                class_weight="balanced",
                max_iter=1000,
                random_state=self.random_state
            )
        else:  # default gradient_boosting
            self.classifier = GradientBoostingClassifier(
                n_estimators=120,
                learning_rate=0.05,
                max_depth=4,
                random_state=self.random_state
            )

        self.is_fitted = False

    def _prepare_structured(self, structured_df: pd.DataFrame, fit: bool = False) -> np.ndarray:
        """Extract, impute, and scale structured financial features without leakage."""
        X_struct = pd.DataFrame(index=structured_df.index)
        for col in self.feature_cols:
            if col in structured_df.columns:
                X_struct[col] = pd.to_numeric(structured_df[col], errors="coerce")
            else:
                X_struct[col] = np.nan

        if fit:
            imputed = self.imputer.fit_transform(X_struct)
            scaled = self.scaler.fit_transform(imputed)
        else:
            imputed = self.imputer.transform(X_struct)
            scaled = self.scaler.transform(imputed)

        return scaled

    def _fuse_features(
        self,
        texts: List[str],
        structured_df: pd.DataFrame,
        fit: bool = False
    ) -> np.ndarray:
        """Extract text embeddings and concatenate with processed structured features."""
        # 1. Dense text embeddings (N, 384)
        text_embs = self.embedder.generate_embeddings(texts, show_progress_bar=False)

        # 2. Processed structured features (N, 14)
        struct_feats = self._prepare_structured(structured_df, fit=fit)

        # 3. Concatenate along feature axis (N, 398)
        fused = np.hstack([text_embs, struct_feats])
        return fused

    def fit(
        self,
        train_texts: List[str],
        train_structured_df: pd.DataFrame,
        train_labels: List[int]
    ) -> "MultimodalFusionClassifier":
        """Fit preprocessing transformers and classifier strictly on train split."""
        fused_X = self._fuse_features(train_texts, train_structured_df, fit=True)
        y = np.array(train_labels).astype(int)

        self.classifier.fit(fused_X, y)
        self.is_fitted = True
        print(f"[MultimodalFusion] Fitted {self.classifier_type} on {len(train_texts)} samples (Fused dim: {fused_X.shape[1]}).")
        return self

    def predict_proba(
        self,
        texts: List[str],
        structured_df: pd.DataFrame
    ) -> np.ndarray:
        """Calculate probability of deal outcome."""
        if not self.is_fitted:
            raise RuntimeError("MultimodalFusionClassifier is not fitted yet.")
        fused_X = self._fuse_features(texts, structured_df, fit=False)
        return self.classifier.predict_proba(fused_X)[:, 1]

    def predict(
        self,
        texts: List[str],
        structured_df: pd.DataFrame,
        threshold: float = 0.5
    ) -> np.ndarray:
        """Calculate binary prediction."""
        probs = self.predict_proba(texts, structured_df)
        return (probs >= threshold).astype(int)

    def evaluate(
        self,
        texts: List[str],
        structured_df: pd.DataFrame,
        labels: List[int]
    ) -> Dict[str, float]:
        """Compute performance metrics on validation or test split."""
        y_true = np.array(labels).astype(int)
        probs = self.predict_proba(texts, structured_df)
        preds = (probs >= 0.5).astype(int)

        return {
            "accuracy": float(round(accuracy_score(y_true, preds), 4)),
            "precision": float(round(precision_score(y_true, preds, zero_division=0), 4)),
            "recall": float(round(recall_score(y_true, preds, zero_division=0), 4)),
            "f1_score": float(round(f1_score(y_true, preds, zero_division=0), 4)),
            "roc_auc": float(round(roc_auc_score(y_true, probs), 4))
        }

    def save(self, filepath: Union[str, Path]) -> None:
        """Save classifier and transformers to disk."""
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({
            "classifier": self.classifier,
            "classifier_type": self.classifier_type,
            "imputer": self.imputer,
            "scaler": self.scaler,
            "feature_cols": self.feature_cols
        }, path)
        print(f"[MultimodalFusion] Saved model to: {path}")

    @classmethod
    def load(
        cls,
        filepath: Union[str, Path],
        embedding_generator: Optional[EmbeddingGenerator] = None
    ) -> "MultimodalFusionClassifier":
        """Load model and transformers from disk."""
        data = joblib.load(filepath)
        obj = cls(
            classifier_type=data["classifier_type"],
            feature_cols=data["feature_cols"],
            embedding_generator=embedding_generator
        )
        obj.classifier = data["classifier"]
        obj.imputer = data["imputer"]
        obj.scaler = data["scaler"]
        obj.is_fitted = True
        return obj
