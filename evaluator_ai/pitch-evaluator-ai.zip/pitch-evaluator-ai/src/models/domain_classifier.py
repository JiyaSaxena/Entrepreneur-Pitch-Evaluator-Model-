"""Startup domain / industry classification module.

Predicts the industry/sector of a startup from its pitch text using
TF-IDF feature representation and calibrated multinomial Logistic Regression.
Handles rare categories and provides top-k predictions with confidence scores.
"""

from pathlib import Path
from typing import List, Dict, Tuple, Optional, Any, Union
import numpy as np
import pandas as pd
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score, f1_score
from ..nlp.preprocessor import clean_text_classical


class DomainClassifier:
    """Domain and industry classifier with confidence estimation."""

    def __init__(
        self,
        min_samples_per_class: int = 15,
        max_features: int = 1500,
        ngram_range: Tuple[int, int] = (1, 2),
        C: float = 1.0,
        random_state: int = 42
    ):
        self.min_samples_per_class = min_samples_per_class
        self.max_features = max_features
        self.ngram_range = ngram_range
        self.C = C
        self.random_state = random_state

        self.vectorizer = TfidfVectorizer(
            min_df=2,
            max_features=self.max_features,
            ngram_range=self.ngram_range,
            sublinear_tf=True
        )
        self.classifier = LogisticRegression(
            C=self.C,
            class_weight="balanced",
            max_iter=1000,
            random_state=self.random_state
        )
        self.classes_: List[str] = []
        self.is_fitted = False

    def _filter_rare_classes(self, labels: pd.Series) -> pd.Series:
        """Consolidate rare classes below threshold into 'Other'."""
        counts = labels.value_counts()
        rare = counts[counts < self.min_samples_per_class].index.tolist()
        return labels.apply(lambda x: "Other" if x in rare or pd.isna(x) or x == "Unknown" else x)

    def fit(self, texts: List[str], labels: List[str]) -> "DomainClassifier":
        """Fit domain classifier strictly on training set."""
        series_labels = pd.Series(labels)
        processed_labels = self._filter_rare_classes(series_labels)

        clean_texts = [clean_text_classical(t) for t in texts]
        X = self.vectorizer.fit_transform(clean_texts)
        y = processed_labels.values

        self.classifier.fit(X, y)
        self.classes_ = list(self.classifier.classes_)
        self.is_fitted = True
        print(f"[DomainClassifier] Fitted successfully on {len(texts)} samples across {len(self.classes_)} classes.")
        return self

    def predict_single(self, text: str, top_k: int = 3) -> Dict[str, Any]:
        """Predict domain for a single pitch text with confidence and top-k ranking.

        Returns:
            Dict with:
                - predicted_domain: str
                - confidence: float (0.0 to 1.0)
                - top_k_predictions: List[Dict[domain, confidence]]
        """
        if not self.is_fitted:
            raise RuntimeError("DomainClassifier is not fitted yet.")

        clean = clean_text_classical(text)
        X = self.vectorizer.transform([clean])
        probs = self.classifier.predict_proba(X)[0]

        top_indices = probs.argsort()[::-1][:top_k]
        predicted_class = self.classes_[top_indices[0]]
        confidence = float(round(probs[top_indices[0]], 4))

        top_preds = [
            {"domain": self.classes_[idx], "confidence": float(round(probs[idx], 4))}
            for idx in top_indices
        ]

        return {
            "predicted_domain": predicted_class,
            "confidence": confidence,
            "top_k_predictions": top_preds
        }

    def evaluate(self, texts: List[str], labels: List[str]) -> Dict[str, Any]:
        """Evaluate model on validation or test split."""
        if not self.is_fitted:
            raise RuntimeError("DomainClassifier is not fitted yet.")

        clean_texts = [clean_text_classical(t) for t in texts]
        X = self.vectorizer.transform(clean_texts)
        processed_labels = self._filter_rare_classes(pd.Series(labels)).values

        preds = self.classifier.predict(X)
        acc = accuracy_score(processed_labels, preds)
        macro_f1 = f1_score(processed_labels, preds, average="macro", zero_division=0)
        report = classification_report(processed_labels, preds, zero_division=0, output_dict=True)

        return {
            "accuracy": float(round(acc, 4)),
            "macro_f1": float(round(macro_f1, 4)),
            "classification_report": report
        }

    def save(self, filepath: Union[str, Path]) -> None:
        """Save classifier and vectorizer to disk."""
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({
            "vectorizer": self.vectorizer,
            "classifier": self.classifier,
            "classes_": self.classes_,
            "min_samples_per_class": self.min_samples_per_class
        }, path)
        print(f"[DomainClassifier] Saved model to: {path}")

    @classmethod
    def load(cls, filepath: Union[str, Path]) -> "DomainClassifier":
        """Load saved classifier from disk."""
        data = joblib.load(filepath)
        obj = cls(min_samples_per_class=data["min_samples_per_class"])
        obj.vectorizer = data["vectorizer"]
        obj.classifier = data["classifier"]
        obj.classes_ = data["classes_"]
        obj.is_fitted = True
        return obj
