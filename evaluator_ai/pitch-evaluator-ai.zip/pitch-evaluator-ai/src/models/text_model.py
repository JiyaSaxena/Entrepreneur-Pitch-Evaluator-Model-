"""Text-only deal prediction model.

Uses TF-IDF feature extraction combined with Logistic Regression to predict
investment / deal outcome solely from the textual pitch narrative.
"""

from pathlib import Path
from typing import List, Dict, Optional, Any, Union
import numpy as np
import pandas as pd
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from ..nlp.preprocessor import clean_text_classical


class TextDealClassifier:
    """TF-IDF + Logistic Regression text deal classifier."""

    def __init__(
        self,
        min_df: int = 2,
        max_features: int = 1000,
        ngram_range: tuple = (1, 2),
        C: float = 1.0,
        random_state: int = 42
    ):
        self.min_df = min_df
        self.max_features = max_features
        self.ngram_range = ngram_range
        self.C = C
        self.random_state = random_state

        self.vectorizer = TfidfVectorizer(
            min_df=self.min_df,
            max_features=self.max_features,
            ngram_range=self.ngram_range,
            sublinear_tf=True
        )
        self.classifier = LogisticRegression(
            C=self.C,
            class_weight="balanced",
            max_iter=1000,
            random_state=self.random_state
        )
        self.is_fitted = False

    def fit(self, texts: List[str], labels: List[int]) -> "TextDealClassifier":
        """Fit vectorizer and classifier strictly on training set."""
        clean_texts = [clean_text_classical(t) for t in texts]
        X = self.vectorizer.fit_transform(clean_texts)
        y = np.array(labels).astype(int)

        self.classifier.fit(X, y)
        self.is_fitted = True
        print(f"[TextDealClassifier] Fitted on {len(texts)} samples with {X.shape[1]} TF-IDF features.")
        return self

    def predict_proba(self, texts: List[str]) -> np.ndarray:
        """Return probability of deal outcome."""
        if not self.is_fitted:
            raise RuntimeError("TextDealClassifier is not fitted yet.")
        clean_texts = [clean_text_classical(t) for t in texts]
        X = self.vectorizer.transform(clean_texts)
        return self.classifier.predict_proba(X)[:, 1]

    def predict(self, texts: List[str], threshold: float = 0.5) -> np.ndarray:
        """Return binary prediction (1 or 0)."""
        probs = self.predict_proba(texts)
        return (probs >= threshold).astype(int)

    def evaluate(self, texts: List[str], labels: List[int]) -> Dict[str, float]:
        """Evaluate performance metrics on validation or test split."""
        y_true = np.array(labels).astype(int)
        probs = self.predict_proba(texts)
        preds = (probs >= 0.5).astype(int)

        return {
            "accuracy": float(round(accuracy_score(y_true, preds), 4)),
            "precision": float(round(precision_score(y_true, preds, zero_division=0), 4)),
            "recall": float(round(recall_score(y_true, preds, zero_division=0), 4)),
            "f1_score": float(round(f1_score(y_true, preds, zero_division=0), 4)),
            "roc_auc": float(round(roc_auc_score(y_true, probs), 4))
        }

    def save(self, filepath: Union[str, Path]) -> None:
        """Save vectorizer and model to disk."""
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({
            "vectorizer": self.vectorizer,
            "classifier": self.classifier,
            "params": {
                "min_df": self.min_df,
                "max_features": self.max_features,
                "ngram_range": self.ngram_range,
                "C": self.C
            }
        }, path)
        print(f"[TextDealClassifier] Saved to: {path}")

    @classmethod
    def load(cls, filepath: Union[str, Path]) -> "TextDealClassifier":
        """Load saved model from disk."""
        data = joblib.load(filepath)
        p = data["params"]
        obj = cls(min_df=p["min_df"], max_features=p["max_features"], ngram_range=p["ngram_range"], C=p["C"])
        obj.vectorizer = data["vectorizer"]
        obj.classifier = data["classifier"]
        obj.is_fitted = True
        return obj
