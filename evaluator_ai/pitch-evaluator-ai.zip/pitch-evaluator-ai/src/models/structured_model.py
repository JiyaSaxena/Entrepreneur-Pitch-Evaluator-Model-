"""Structured-data deal prediction model.

Trains classical machine learning models (Random Forest, Gradient Boosting, Logistic Regression)
on legitimate pre-decision business indicators (Revenue, Sales, Margins, Ask, Equity, Valuation, Patents).
Strictly excludes all post-decision leakage columns.
"""

from pathlib import Path
from typing import List, Dict, Optional, Any, Union
import numpy as np
import pandas as pd
import joblib
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score


STRUCTURED_FEATURE_COLS = [
    "yearly_revenue",
    "monthly_sales",
    "gross_margin",
    "net_margin",
    "ebitda",
    "cash_burn",
    "has_patents",
    "bootstrapped",
    "skus",
    "original_ask_amount",
    "original_offered_equity",
    "valuation_requested",
    "revenue_to_ask_ratio",
    "valuation_to_revenue_ratio"
]


class StructuredDealClassifier:
    """Pre-decision structured financial deal classification model."""

    def __init__(
        self,
        model_type: str = "gradient_boosting",
        feature_cols: Optional[List[str]] = None,
        random_state: int = 42
    ):
        self.model_type = model_type
        self.feature_cols = feature_cols or STRUCTURED_FEATURE_COLS
        self.random_state = random_state

        if model_type == "random_forest":
            base_clf = RandomForestClassifier(
                n_estimators=150,
                max_depth=6,
                class_weight="balanced",
                random_state=self.random_state
            )
        elif model_type == "logistic_regression":
            base_clf = LogisticRegression(
                C=1.0,
                class_weight="balanced",
                max_iter=1000,
                random_state=self.random_state
            )
        else:  # default gradient_boosting
            base_clf = GradientBoostingClassifier(
                n_estimators=100,
                learning_rate=0.05,
                max_depth=3,
                random_state=self.random_state
            )

        self.pipeline = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("classifier", base_clf)
        ])
        self.is_fitted = False

    def _extract_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Extract and ensure all expected numeric feature columns exist."""
        X = pd.DataFrame(index=df.index)
        for col in self.feature_cols:
            if col in df.columns:
                X[col] = pd.to_numeric(df[col], errors="coerce")
            else:
                X[col] = np.nan
        return X

    def fit(self, train_df: pd.DataFrame, target_col: str = "investment_decision") -> "StructuredDealClassifier":
        """Fit preprocessing pipeline and classifier strictly on train split."""
        X_train = self._extract_features(train_df)
        y_train = train_df[target_col].astype(int).values

        self.pipeline.fit(X_train, y_train)
        self.is_fitted = True
        print(f"[StructuredDealClassifier] Fitted {self.model_type} on {len(train_df)} samples using {len(self.feature_cols)} features.")
        return self

    def predict_proba(self, df: pd.DataFrame) -> np.ndarray:
        """Return probability of receiving investment / deal."""
        if not self.is_fitted:
            raise RuntimeError("StructuredDealClassifier is not fitted yet.")
        X = self._extract_features(df)
        return self.pipeline.predict_proba(X)[:, 1]

    def predict(self, df: pd.DataFrame, threshold: float = 0.5) -> np.ndarray:
        """Return binary prediction (1 or 0) using decision threshold."""
        probs = self.predict_proba(df)
        return (probs >= threshold).astype(int)

    def evaluate(self, test_df: pd.DataFrame, target_col: str = "investment_decision") -> Dict[str, float]:
        """Evaluate performance metrics on test or validation split."""
        y_true = test_df[target_col].astype(int).values
        probs = self.predict_proba(test_df)
        preds = (probs >= 0.5).astype(int)

        return {
            "accuracy": float(round(accuracy_score(y_true, preds), 4)),
            "precision": float(round(precision_score(y_true, preds, zero_division=0), 4)),
            "recall": float(round(recall_score(y_true, preds, zero_division=0), 4)),
            "f1_score": float(round(f1_score(y_true, preds, zero_division=0), 4)),
            "roc_auc": float(round(roc_auc_score(y_true, probs), 4))
        }

    def save(self, filepath: Union[str, Path]) -> None:
        """Save pipeline to disk."""
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({
            "pipeline": self.pipeline,
            "feature_cols": self.feature_cols,
            "model_type": self.model_type
        }, path)
        print(f"[StructuredDealClassifier] Saved to: {path}")

    @classmethod
    def load(cls, filepath: Union[str, Path]) -> "StructuredDealClassifier":
        """Load pipeline from disk."""
        data = joblib.load(filepath)
        obj = cls(model_type=data["model_type"], feature_cols=data["feature_cols"])
        obj.pipeline = data["pipeline"]
        obj.is_fitted = True
        return obj
