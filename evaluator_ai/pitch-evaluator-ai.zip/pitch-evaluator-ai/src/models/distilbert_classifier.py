"""DistilBERT fine-tuning and inference module for startup deal classification.

Implements a lightweight PyTorch training pipeline with:
- distilbert-base-uncased architecture
- Dynamic tokenization & attention masks
- GPU acceleration with automatic CPU fallback
- Validation evaluation and early stopping
- Model checkpointing & separate tokenizer saving
"""

import os
from pathlib import Path
from typing import List, Dict, Tuple, Optional, Any, Union
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import AutoTokenizer, AutoModelForSequenceClassification, AutoConfig
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from ..nlp.preprocessor import clean_text_transformer


MODEL_NAME = "distilbert-base-uncased"


class PitchDataset(Dataset):
    """PyTorch Dataset for tokenized startup pitch texts."""

    def __init__(self, encodings: Dict[str, torch.Tensor], labels: Optional[List[int]] = None):
        self.encodings = encodings
        self.labels = labels

    def __len__(self) -> int:
        return len(self.encodings["input_ids"])

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        item = {key: val[idx] for key, val in self.encodings.items()}
        if self.labels is not None:
            item["labels"] = torch.tensor(self.labels[idx], dtype=torch.long)
        return item


class DistilBertDealClassifier:
    """DistilBERT fine-tuning and inference wrapper."""

    def __init__(
        self,
        model_name: str = MODEL_NAME,
        max_length: int = 128,
        batch_size: int = 16,
        learning_rate: float = 2e-5,
        device: Optional[Union[str, torch.device]] = None
    ):
        self.model_name = model_name
        self.max_length = max_length
        self.batch_size = batch_size
        self.learning_rate = learning_rate

        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device)

        print(f"[DistilBert] Initializing on device: {self.device}")
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self.model = AutoModelForSequenceClassification.from_pretrained(self.model_name, num_labels=2)
        self.model.to(self.device)
        self.is_trained = False

    def _tokenize(self, texts: List[str]) -> Dict[str, torch.Tensor]:
        """Clean and tokenize batch of texts."""
        cleaned = [clean_text_transformer(t) for t in texts]
        return self.tokenizer(
            cleaned,
            padding=True,
            truncation=True,
            max_length=self.max_length,
            return_tensors="pt"
        )

    def train(
        self,
        train_texts: List[str],
        train_labels: List[int],
        val_texts: List[str],
        val_labels: List[int],
        epochs: int = 2,
        save_dir: Optional[Union[str, Path]] = None
    ) -> Dict[str, List[float]]:
        """Fine-tune DistilBERT with validation tracking and early stopping."""
        train_encodings = self._tokenize(train_texts)
        val_encodings = self._tokenize(val_texts)

        train_dataset = PitchDataset(train_encodings, train_labels)
        val_dataset = PitchDataset(val_encodings, val_labels)

        train_loader = DataLoader(train_dataset, batch_size=self.batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=self.batch_size, shuffle=False)

        optimizer = torch.optim.AdamW(self.model.parameters(), lr=self.learning_rate, weight_decay=0.01)
        loss_fn = nn.CrossEntropyLoss()

        history = {"train_loss": [], "val_loss": [], "val_f1": []}
        best_val_f1 = -1.0

        print(f"[DistilBert] Starting training for {epochs} epochs (Batch size: {self.batch_size})...")

        for epoch in range(1, epochs + 1):
            # Training Phase
            self.model.train()
            running_loss = 0.0

            for batch in train_loader:
                optimizer.zero_grad()
                input_ids = batch["input_ids"].to(self.device)
                attention_mask = batch["attention_mask"].to(self.device)
                labels = batch["labels"].to(self.device)

                outputs = self.model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
                loss = outputs.loss
                loss.backward()
                optimizer.step()
                running_loss += loss.item() * len(input_ids)

            epoch_train_loss = running_loss / len(train_dataset)

            # Validation Phase
            val_metrics = self.evaluate(val_texts, val_labels)
            val_f1 = val_metrics["f1_score"]

            history["train_loss"].append(float(round(epoch_train_loss, 4)))
            history["val_loss"].append(float(round(val_metrics.get("loss", 0.0), 4)))
            history["val_f1"].append(float(round(val_f1, 4)))

            print(f"  Epoch {epoch}/{epochs} - Train Loss: {epoch_train_loss:.4f} | Val F1: {val_f1:.4f} | Val Acc: {val_metrics['accuracy']:.4f}")

            # Checkpointing
            if val_f1 > best_val_f1 and save_dir is not None:
                best_val_f1 = val_f1
                self.save(save_dir)

        self.is_trained = True
        return history

    def predict_proba(self, texts: List[str]) -> np.ndarray:
        """Calculate deal probability for a list of texts."""
        self.model.eval()
        encodings = self._tokenize(texts)
        dataset = PitchDataset(encodings)
        loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=False)

        all_probs = []
        with torch.no_grad():
            for batch in loader:
                input_ids = batch["input_ids"].to(self.device)
                attention_mask = batch["attention_mask"].to(self.device)
                outputs = self.model(input_ids=input_ids, attention_mask=attention_mask)
                logits = outputs.logits
                probs = torch.softmax(logits, dim=1)[:, 1].cpu().numpy()
                all_probs.extend(probs)

        return np.array(all_probs)

    def predict(self, texts: List[str], threshold: float = 0.5) -> np.ndarray:
        """Calculate binary predictions for a list of texts."""
        probs = self.predict_proba(texts)
        return (probs >= threshold).astype(int)

    def evaluate(self, texts: List[str], labels: List[int]) -> Dict[str, float]:
        """Compute comprehensive classification metrics."""
        y_true = np.array(labels).astype(int)
        probs = self.predict_proba(texts)
        preds = (probs >= 0.5).astype(int)

        return {
            "accuracy": float(round(accuracy_score(y_true, preds), 4)),
            "precision": float(round(precision_score(y_true, preds, zero_division=0), 4)),
            "recall": float(round(recall_score(y_true, preds, zero_division=0), 4)),
            "f1_score": float(round(f1_score(y_true, preds, zero_division=0), 4)),
            "roc_auc": float(round(roc_auc_score(y_true, probs), 4))
        }

    def save(self, directory: Union[str, Path]) -> None:
        """Save fine-tuned model and tokenizer to directory."""
        save_path = Path(directory)
        save_path.mkdir(parents=True, exist_ok=True)
        self.model.save_pretrained(str(save_path))
        self.tokenizer.save_pretrained(str(save_path))
        print(f"[DistilBert] Saved model checkpoint and tokenizer to: {save_path}")

    @classmethod
    def load(cls, directory: Union[str, Path], device: Optional[Union[str, torch.device]] = None) -> "DistilBertDealClassifier":
        """Load fine-tuned model and tokenizer from directory."""
        load_path = Path(directory)
        obj = cls(model_name=str(load_path), device=device)
        obj.is_trained = True
        print(f"[DistilBert] Loaded fine-tuned checkpoint from: {load_path}")
        return obj
